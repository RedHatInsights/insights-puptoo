total 0
drwxr-xr-x. 3 0 0    0 Jan 18 03:20 .
drwxr-xr-x. 4 0 0    0 Jan 18 03:20 ..
drwxr-xr-x. 2 0 0    0 Jan 18 18:41 power
lrwxrwxrwx. 1 0 0    0 Jan 18 03:20 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Jan 18 03:20 uevent
