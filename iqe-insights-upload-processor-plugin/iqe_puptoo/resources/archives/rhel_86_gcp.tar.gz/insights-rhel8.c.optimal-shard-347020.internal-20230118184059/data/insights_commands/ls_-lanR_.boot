/boot:
total 208048
dr-xr-xr-x.  5 0 0     4096 Jan 18 03:32 .
dr-xr-xr-x. 17 0 0      224 Jun 29  2022 ..
-rw-r--r--.  1 0 0      170 Apr 16  2022 .vmlinuz-4.18.0-372.9.1.el8.x86_64.hmac
-rw-r--r--.  1 0 0      173 Dec 14 21:12 .vmlinuz-4.18.0-425.10.1.el8_7.x86_64.hmac
-rw-------.  1 0 0  4359450 Apr 16  2022 System.map-4.18.0-372.9.1.el8.x86_64
-rw-------.  1 0 0  4405856 Dec 14 21:13 System.map-4.18.0-425.10.1.el8_7.x86_64
-rw-r--r--.  1 0 0   195982 Apr 16  2022 config-4.18.0-372.9.1.el8.x86_64
-rw-r--r--.  1 0 0   198585 Dec 14 21:13 config-4.18.0-425.10.1.el8_7.x86_64
drwx------.  3 0 0    16384 Jan  1  1970 efi
drwx------.  2 0 0       21 Nov  8 17:08 grub2
-rw-------.  1 0 0 80579092 Jun 29  2022 initramfs-0-rescue-ae3dcb4ad8b7d96d492f2e22731ab183.img
-rw-------.  1 0 0 32744507 Jun 29  2022 initramfs-4.18.0-372.9.1.el8.x86_64.img
-rw-------.  1 0 0 27949568 Jul  7  2022 initramfs-4.18.0-372.9.1.el8.x86_64kdump.img
-rw-------.  1 0 0 30898234 Jan 18 03:32 initramfs-4.18.0-425.10.1.el8_7.x86_64.img
drwxr-xr-x.  3 0 0       21 Jun 29  2022 loader
lrwxrwxrwx.  1 0 0       49 Jun 29  2022 symvers-4.18.0-372.9.1.el8.x86_64.gz -> /lib/modules/4.18.0-372.9.1.el8.x86_64/symvers.gz
lrwxrwxrwx.  1 0 0       52 Jan 18 03:30 symvers-4.18.0-425.10.1.el8_7.x86_64.gz -> /lib/modules/4.18.0-425.10.1.el8_7.x86_64/symvers.gz
-rwxr-xr-x.  1 0 0 10460528 Jun 29  2022 vmlinuz-0-rescue-ae3dcb4ad8b7d96d492f2e22731ab183
-rwxr-xr-x.  1 0 0 10460528 Apr 16  2022 vmlinuz-4.18.0-372.9.1.el8.x86_64
-rwxr-xr-x.  1 0 0 10743152 Dec 14 21:13 vmlinuz-4.18.0-425.10.1.el8_7.x86_64

/boot/efi:
total 24
drwx------. 3 0 0 16384 Jan  1  1970 .
dr-xr-xr-x. 5 0 0  4096 Jan 18 03:32 ..
drwx------. 4 0 0  4096 Jun 29  2022 EFI

/boot/efi/EFI:
total 28
drwx------. 4 0 0  4096 Jun 29  2022 .
drwx------. 3 0 0 16384 Jan  1  1970 ..
drwx------. 2 0 0  4096 Jun 29  2022 BOOT
drwx------. 3 0 0  4096 Jan 18 03:29 redhat

/boot/efi/EFI/BOOT:
total 1024
drwx------. 2 0 0   4096 Jun 29  2022 .
drwx------. 4 0 0   4096 Jun 29  2022 ..
-rwx------. 1 0 0 943520 Jun  7  2022 BOOTX64.EFI
-rwx------. 1 0 0  90568 Jun  7  2022 fbx64.efi

/boot/efi/EFI/redhat:
total 4868
drwx------. 3 0 0    4096 Jan 18 03:29 .
drwx------. 4 0 0    4096 Jun 29  2022 ..
-rwx------. 1 0 0     182 Jun  7  2022 BOOTX64.CSV
drwx------. 2 0 0    4096 Nov  8 17:08 fonts
-rwx------. 1 0 0    6133 Jun 29  2022 grub.cfg
-rwx------. 1 0 0    1024 Jan 18 03:30 grubenv
-rwx------. 1 0 0 2215880 Nov  8 17:08 grubx64.efi
-rwx------. 1 0 0  852552 Jun  7  2022 mmx64.efi
-rwx------. 1 0 0  936520 Jun  7  2022 shimx64-redhat.efi
-rwx------. 1 0 0  943520 Jun  7  2022 shimx64.efi

/boot/efi/EFI/redhat/fonts:
total 8
drwx------. 2 0 0 4096 Nov  8 17:08 .
drwx------. 3 0 0 4096 Jan 18 03:29 ..

/boot/grub2:
total 4
drwx------. 2 0 0   21 Nov  8 17:08 .
dr-xr-xr-x. 5 0 0 4096 Jan 18 03:32 ..
lrwxrwxrwx. 1 0 0   25 Nov  8 17:08 grubenv -> ../efi/EFI/redhat/grubenv

/boot/loader:
total 4
drwxr-xr-x. 3 0 0   21 Jun 29  2022 .
dr-xr-xr-x. 5 0 0 4096 Jan 18 03:32 ..
drwx------. 2 0 0  205 Jan 18 03:32 entries

/boot/loader/entries:
total 12
drwx------. 2 0 0 205 Jan 18 03:32 .
drwxr-xr-x. 3 0 0  21 Jun 29  2022 ..
-rw-r--r--. 1 0 0 418 Jun 29  2022 ae3dcb4ad8b7d96d492f2e22731ab183-0-rescue.conf
-rw-r--r--. 1 0 0 366 Jun 29  2022 ae3dcb4ad8b7d96d492f2e22731ab183-4.18.0-372.9.1.el8.x86_64.conf
-rw-r--r--. 1 0 0 381 Jan 18 03:32 ae3dcb4ad8b7d96d492f2e22731ab183-4.18.0-425.10.1.el8_7.x86_64.conf
