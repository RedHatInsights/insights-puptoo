total 0
drwxr-xr-x. 3 0 0    0 Apr 25 15:26 .
drwxr-xr-x. 4 0 0    0 Apr 25 15:26 ..
drwxr-xr-x. 2 0 0    0 Apr 25 15:26 power
lrwxrwxrwx. 1 0 0    0 Apr 25 15:26 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Apr 25 15:26 uevent
