/bin/ls: cannot access '/dev/disk/by-label': No such file or directory
/bin/ls: cannot access '/dev/oracleasm/disks': No such file or directory
/bin/ls: cannot access '/etc/watchdog.d': No such file or directory
/bin/ls: cannot access '/usr/share/ipa/ui/js/plugins/idoverride-memberof': No such file or directory
/bin/ls: cannot access '/var/opt/mssql/log': No such file or directory
/bin/ls: cannot access '/var/spool/postfix': No such file or directory
/bin/ls: cannot access '/var/www': No such file or directory
lrwxrwxrwx.  1   0   0   11 Feb  7 08:00 /etc/yum/vars -> ../dnf/vars
lrwxrwxrwx.  1   0   0   26 Apr 23 14:52 /var/lib/rpm -> ../../usr/lib/sysimage/rpm
lrwxrwxrwx.  1   0   0    6 Apr 23 14:51 /var/run -> ../run

/:
total 24
dr-xr-xr-x.  18 0 0  235 Apr 23 14:51 .
dr-xr-xr-x.  18 0 0  235 Apr 23 14:51 ..
dr-xr-xr-x.   2 0 0    6 Oct 29  2024 afs
lrwxrwxrwx.   1 0 0    7 Oct 29  2024 bin -> usr/bin
dr-xr-xr-x.   5 0 0 4096 Apr 23 16:02 boot
drwxr-xr-x.  21 0 0 3380 May 22 12:42 dev
drwxr-xr-x.  92 0 0 8192 Jul 10 12:13 etc
drwxr-xr-x.   2 0 0    6 Oct 29  2024 home
lrwxrwxrwx.   1 0 0    7 Oct 29  2024 lib -> usr/lib
lrwxrwxrwx.   1 0 0    9 Oct 29  2024 lib64 -> usr/lib64
drwxr-xr-x.   2 0 0    6 Oct 29  2024 media
drwxr-xr-x.   2 0 0    6 Oct 29  2024 mnt
drwxr-xr-x.   2 0 0    6 Oct 29  2024 opt
dr-xr-xr-x. 222 0 0    0 May 22 12:42 proc
dr-xr-x---.   3 0 0  163 Jul  2 11:08 root
drwxr-xr-x.  36 0 0 1020 Jul 10 15:29 run
lrwxrwxrwx.   1 0 0    8 Oct 29  2024 sbin -> usr/sbin
drwxr-xr-x.   2 0 0    6 Oct 29  2024 srv
dr-xr-xr-x.  13 0 0    0 May 22 12:42 sys
drwxrwxrwt.  10 0 0 4096 Jul 10 15:29 tmp
drwxr-xr-x.  12 0 0  144 Apr 23 14:51 usr
drwxr-xr-x.  19 0 0 4096 Apr 23 16:02 var

/dev:
total 0
drwxr-xr-x. 21 0  0     3380 May 22 12:42 .
dr-xr-xr-x. 18 0  0      235 Apr 23 14:51 ..
crw-r--r--.  1 0  0  10, 235 May 22 12:42 autofs
drwxr-xr-x.  2 0  0      180 Jul 10 01:24 block
drwxr-xr-x.  2 0  0       60 May 22 12:42 bsg
drwxr-xr-x.  3 0  0       60 May 22 12:42 bus
lrwxrwxrwx.  1 0  0        3 May 22 12:42 cdrom -> sr0
drwxr-xr-x.  2 0  0     2980 May 22 12:42 char
crw--w----.  1 0  5   5,   1 May 22 12:42 console
lrwxrwxrwx.  1 0  0       11 May 22 12:42 core -> /proc/kcore
drwxr-xr-x.  4 0  0       80 May 22 12:42 cpu
crw-------.  1 0  0  10, 124 May 22 12:42 cpu_dma_latency
crw-------.  1 0  0  10, 203 May 22 12:42 cuse
drwxr-xr-x.  7 0  0      140 May 22 12:42 disk
brw-rw----.  1 0  6 253,   0 May 22 12:42 dm-0
brw-rw----.  1 0  6 253,   1 May 22 12:42 dm-1
drwxr-xr-x.  2 0  0       60 May 22 12:42 dma_heap
drwxr-xr-x.  3 0  0      100 May 22 12:42 dri
lrwxrwxrwx.  1 0  0       13 May 22 12:42 fd -> /proc/self/fd
crw-rw-rw-.  1 0  0   1,   7 May 22 12:42 full
crw-rw-rw-.  1 0  0  10, 229 May 22 12:42 fuse
crw-------.  1 0  0 242,   0 May 22 12:42 hidraw0
crw-------.  1 0  0  10, 228 May 22 12:42 hpet
drwxr-xr-x.  2 0  0        0 May 22 12:42 hugepages
crw-------.  1 0  0  10, 183 May 22 12:42 hwrng
lrwxrwxrwx.  1 0  0       12 May 22 12:42 initctl -> /run/initctl
drwxr-xr-x.  4 0  0      280 May 22 12:42 input
crw-r--r--.  1 0  0   1,  11 May 22 12:42 kmsg
crw-rw-rw-.  1 0 36  10, 232 May 22 12:42 kvm
lrwxrwxrwx.  1 0  0       28 May 22 12:42 log -> /run/systemd/journal/dev-log
crw-rw----.  1 0  6  10, 237 May 22 12:42 loop-control
drwxr-xr-x.  2 0  0      100 May 22 12:42 mapper
crw-------.  1 0  0  10, 227 May 22 12:42 mcelog
crw-r-----.  1 0  9   1,   1 May 22 12:42 mem
drwxrwxrwt.  2 0  0       40 May 22 12:42 mqueue
drwxr-xr-x.  2 0  0       60 May 22 12:42 net
crw-rw-rw-.  1 0  0   1,   3 May 22 12:42 null
crw-------.  1 0  0  10, 144 May 22 12:42 nvram
crw-r-----.  1 0  9   1,   4 May 22 12:42 port
crw-------.  1 0  0 108,   0 May 22 12:42 ppp
crw-rw-rw-.  1 0  5   5,   2 Jul 10 15:29 ptmx
drwxr-xr-x.  2 0  0        0 May 22 12:42 pts
crw-rw-rw-.  1 0  0   1,   8 May 22 12:42 random
crw-rw-r--.  1 0  0  10, 242 May 22 12:42 rfkill
drwxr-xr-x.  2 0  0       80 May 22 12:42 rhel_bootp-73-213-208
lrwxrwxrwx.  1 0  0        4 May 22 12:42 rtc -> rtc0
crw-------.  1 0  0 250,   0 May 22 12:42 rtc0
crw-rw----.  1 0 11  21,   0 May 22 12:42 sg0
drwxrwxrwt.  2 0  0       40 May 22 12:42 shm
crw-------.  1 0  0  10, 231 May 22 12:42 snapshot
drwxr-xr-x.  2 0  0       80 May 22 12:42 snd
brw-rw----.  1 0 11  11,   0 May 22 12:42 sr0
lrwxrwxrwx.  1 0  0       15 May 22 12:42 stderr -> /proc/self/fd/2
lrwxrwxrwx.  1 0  0       15 May 22 12:42 stdin -> /proc/self/fd/0
lrwxrwxrwx.  1 0  0       15 May 22 12:42 stdout -> /proc/self/fd/1
crw-rw-rw-.  1 0  5   5,   0 May 22 12:42 tty
crw--w----.  1 0  5   4,   0 May 22 12:42 tty0
crw--w----.  1 0  5   4,   1 May 22 12:42 tty1
crw--w----.  1 0  5   4,  10 May 22 12:42 tty10
crw--w----.  1 0  5   4,  11 May 22 12:42 tty11
crw--w----.  1 0  5   4,  12 May 22 12:42 tty12
crw--w----.  1 0  5   4,  13 May 22 12:42 tty13
crw--w----.  1 0  5   4,  14 May 22 12:42 tty14
crw--w----.  1 0  5   4,  15 May 22 12:42 tty15
crw--w----.  1 0  5   4,  16 May 22 12:42 tty16
crw--w----.  1 0  5   4,  17 May 22 12:42 tty17
crw--w----.  1 0  5   4,  18 May 22 12:42 tty18
crw--w----.  1 0  5   4,  19 May 22 12:42 tty19
crw--w----.  1 0  5   4,   2 May 22 12:42 tty2
crw--w----.  1 0  5   4,  20 May 22 12:42 tty20
crw--w----.  1 0  5   4,  21 May 22 12:42 tty21
crw--w----.  1 0  5   4,  22 May 22 12:42 tty22
crw--w----.  1 0  5   4,  23 May 22 12:42 tty23
crw--w----.  1 0  5   4,  24 May 22 12:42 tty24
crw--w----.  1 0  5   4,  25 May 22 12:42 tty25
crw--w----.  1 0  5   4,  26 May 22 12:42 tty26
crw--w----.  1 0  5   4,  27 May 22 12:42 tty27
crw--w----.  1 0  5   4,  28 May 22 12:42 tty28
crw--w----.  1 0  5   4,  29 May 22 12:42 tty29
crw--w----.  1 0  5   4,   3 May 22 12:42 tty3
crw--w----.  1 0  5   4,  30 May 22 12:42 tty30
crw--w----.  1 0  5   4,  31 May 22 12:42 tty31
crw--w----.  1 0  5   4,  32 May 22 12:42 tty32
crw--w----.  1 0  5   4,  33 May 22 12:42 tty33
crw--w----.  1 0  5   4,  34 May 22 12:42 tty34
crw--w----.  1 0  5   4,  35 May 22 12:42 tty35
crw--w----.  1 0  5   4,  36 May 22 12:42 tty36
crw--w----.  1 0  5   4,  37 May 22 12:42 tty37
crw--w----.  1 0  5   4,  38 May 22 12:42 tty38
crw--w----.  1 0  5   4,  39 May 22 12:42 tty39
crw--w----.  1 0  5   4,   4 May 22 12:42 tty4
crw--w----.  1 0  5   4,  40 May 22 12:42 tty40
crw--w----.  1 0  5   4,  41 May 22 12:42 tty41
crw--w----.  1 0  5   4,  42 May 22 12:42 tty42
crw--w----.  1 0  5   4,  43 May 22 12:42 tty43
crw--w----.  1 0  5   4,  44 May 22 12:42 tty44
crw--w----.  1 0  5   4,  45 May 22 12:42 tty45
crw--w----.  1 0  5   4,  46 May 22 12:42 tty46
crw--w----.  1 0  5   4,  47 May 22 12:42 tty47
crw--w----.  1 0  5   4,  48 May 22 12:42 tty48
crw--w----.  1 0  5   4,  49 May 22 12:42 tty49
crw--w----.  1 0  5   4,   5 May 22 12:42 tty5
crw--w----.  1 0  5   4,  50 May 22 12:42 tty50
crw--w----.  1 0  5   4,  51 May 22 12:42 tty51
crw--w----.  1 0  5   4,  52 May 22 12:42 tty52
crw--w----.  1 0  5   4,  53 May 22 12:42 tty53
crw--w----.  1 0  5   4,  54 May 22 12:42 tty54
crw--w----.  1 0  5   4,  55 May 22 12:42 tty55
crw--w----.  1 0  5   4,  56 May 22 12:42 tty56
crw--w----.  1 0  5   4,  57 May 22 12:42 tty57
crw--w----.  1 0  5   4,  58 May 22 12:42 tty58
crw--w----.  1 0  5   4,  59 May 22 12:42 tty59
crw--w----.  1 0  5   4,   6 May 22 12:42 tty6
crw--w----.  1 0  5   4,  60 May 22 12:42 tty60
crw--w----.  1 0  5   4,  61 May 22 12:42 tty61
crw--w----.  1 0  5   4,  62 May 22 12:42 tty62
crw--w----.  1 0  5   4,  63 May 22 12:42 tty63
crw--w----.  1 0  5   4,   7 May 22 12:42 tty7
crw--w----.  1 0  5   4,   8 May 22 12:42 tty8
crw--w----.  1 0  5   4,   9 May 22 12:42 tty9
crw-rw----.  1 0 18   4,  64 May 22 12:42 ttyS0
crw-rw----.  1 0 18   4,  65 May 22 12:42 ttyS1
crw-rw----.  1 0 18   4,  66 May 22 12:42 ttyS2
crw-rw----.  1 0 18   4,  67 May 22 12:42 ttyS3
crw-rw----.  1 0 36  10, 125 May 22 12:42 udmabuf
crw-------.  1 0  0  10, 239 May 22 12:42 uhid
crw-------.  1 0  0  10, 223 May 22 12:42 uinput
crw-rw-rw-.  1 0  0   1,   9 May 22 12:42 urandom
crw-------.  1 0  0 244,   0 May 22 12:42 usbmon0
crw-------.  1 0  0 244,   1 May 22 12:42 usbmon1
crw-------.  1 0  0 244,   2 May 22 12:42 usbmon2
crw-------.  1 0  0  10, 126 May 22 12:42 userfaultfd
crw-rw----.  1 0  5   7,   0 May 22 12:42 vcs
crw-rw----.  1 0  5   7,   1 May 22 12:42 vcs1
crw-rw----.  1 0  5   7,   2 May 22 12:42 vcs2
crw-rw----.  1 0  5   7,   3 May 22 12:42 vcs3
crw-rw----.  1 0  5   7,   4 May 22 12:42 vcs4
crw-rw----.  1 0  5   7,   5 May 22 12:42 vcs5
crw-rw----.  1 0  5   7,   6 May 22 12:42 vcs6
crw-rw----.  1 0  5   7, 128 May 22 12:42 vcsa
crw-rw----.  1 0  5   7, 129 May 22 12:42 vcsa1
crw-rw----.  1 0  5   7, 130 May 22 12:42 vcsa2
crw-rw----.  1 0  5   7, 131 May 22 12:42 vcsa3
crw-rw----.  1 0  5   7, 132 May 22 12:42 vcsa4
crw-rw----.  1 0  5   7, 133 May 22 12:42 vcsa5
crw-rw----.  1 0  5   7, 134 May 22 12:42 vcsa6
crw-rw----.  1 0  5   7,  64 May 22 12:42 vcsu
crw-rw----.  1 0  5   7,  65 May 22 12:42 vcsu1
crw-rw----.  1 0  5   7,  66 May 22 12:42 vcsu2
crw-rw----.  1 0  5   7,  67 May 22 12:42 vcsu3
crw-rw----.  1 0  5   7,  68 May 22 12:42 vcsu4
crw-rw----.  1 0  5   7,  69 May 22 12:42 vcsu5
crw-rw----.  1 0  5   7,  70 May 22 12:42 vcsu6
brw-rw----.  1 0  6 252,   0 Jul 10 01:24 vda
brw-rw----.  1 0  6 252,   1 Jul 10 01:24 vda1
brw-rw----.  1 0  6 252,   2 Jul 10 01:24 vda2
brw-rw----.  1 0  6 252,   3 Jul 10 01:24 vda3
drwxr-xr-x.  2 0  0       60 May 22 12:42 vfio
crw-------.  1 0  0  10, 127 May 22 12:42 vga_arbiter
crw-------.  1 0  0  10, 137 May 22 12:42 vhci
crw-rw-rw-.  1 0 36  10, 238 May 22 12:42 vhost-net
crw-rw-rw-.  1 0 36  10, 241 May 22 12:42 vhost-vsock
drwxr-xr-x.  2 0  0       60 May 22 12:42 virtio-ports
crw-------.  1 0  0  10, 123 May 22 12:42 vmci
crw-------.  1 0  0 241,   1 May 22 12:42 vport3p1
crw-rw-rw-.  1 0  0  10, 122 May 22 12:42 vsock
crw-------.  1 0  0  10, 130 May 22 12:42 watchdog
crw-------.  1 0  0 247,   0 May 22 12:42 watchdog0
crw-rw-rw-.  1 0  0   1,   5 May 22 12:42 zero

/dev/block:
total 0
drwxr-xr-x.  2 0 0  180 Jul 10 01:24 .
drwxr-xr-x. 21 0 0 3380 May 22 12:42 ..
lrwxrwxrwx.  1 0 0    6 May 22 12:42 11:0 -> ../sr0
lrwxrwxrwx.  1 0 0    6 Jul 10 01:24 252:0 -> ../vda
lrwxrwxrwx.  1 0 0    7 Jul 10 01:24 252:1 -> ../vda1
lrwxrwxrwx.  1 0 0    7 Jul 10 01:24 252:2 -> ../vda2
lrwxrwxrwx.  1 0 0    7 Jul 10 01:24 252:3 -> ../vda3
lrwxrwxrwx.  1 0 0    7 May 22 12:42 253:0 -> ../dm-0
lrwxrwxrwx.  1 0 0    7 May 22 12:42 253:1 -> ../dm-1

/dev/disk/by-id:
total 0
drwxr-xr-x. 2 0 0 160 May 22 12:42 .
drwxr-xr-x. 7 0 0 140 May 22 12:42 ..
lrwxrwxrwx. 1 0 0   9 May 22 12:42 ata-QEMU_DVD-ROM_QM00001 -> ../../sr0
lrwxrwxrwx. 1 0 0  10 May 22 12:42 dm-name-rhel_bootp--73--213--208-root -> ../../dm-0
lrwxrwxrwx. 1 0 0  10 May 22 12:42 dm-name-rhel_bootp--73--213--208-swap -> ../../dm-1
lrwxrwxrwx. 1 0 0  10 May 22 12:42 dm-uuid-LVM-bjqWo6USHiTo6Bmyf72724Di83TR0Y359K3GlK5mcSgdexk3uSZJc39K91mH4rCo -> ../../dm-1
lrwxrwxrwx. 1 0 0  10 May 22 12:42 dm-uuid-LVM-bjqWo6USHiTo6Bmyf72724Di83TR0Y35tvqeQBhyKwzpwI7zW0SyQXBSQ0dymq2w -> ../../dm-0
lrwxrwxrwx. 1 0 0  10 May 22 12:42 lvm-pv-uuid-GTqmYS-sngK-kKiz-EObA-C3dx-h9k0-8fvgc3 -> ../../vda3

/dev/disk/by-path:
total 0
drwxr-xr-x. 3 0 0 260 May 22 12:42 .
drwxr-xr-x. 7 0 0 140 May 22 12:42 ..
lrwxrwxrwx. 1 0 0   9 May 22 12:42 pci-0000:00:1f.2-ata-1 -> ../../sr0
lrwxrwxrwx. 1 0 0   9 May 22 12:42 pci-0000:00:1f.2-ata-1.0 -> ../../sr0
lrwxrwxrwx. 1 0 0   9 May 22 12:42 pci-0000:05:00.0 -> ../../vda
drwxr-xr-x. 5 0 0 100 May 22 12:42 pci-0000:05:00.0-part
lrwxrwxrwx. 1 0 0  10 May 22 12:42 pci-0000:05:00.0-part1 -> ../../vda1
lrwxrwxrwx. 1 0 0  10 May 22 12:42 pci-0000:05:00.0-part2 -> ../../vda2
lrwxrwxrwx. 1 0 0  10 May 22 12:42 pci-0000:05:00.0-part3 -> ../../vda3
lrwxrwxrwx. 1 0 0   9 May 22 12:42 virtio-pci-0000:05:00.0 -> ../../vda
lrwxrwxrwx. 1 0 0  10 May 22 12:42 virtio-pci-0000:05:00.0-part1 -> ../../vda1
lrwxrwxrwx. 1 0 0  10 May 22 12:42 virtio-pci-0000:05:00.0-part2 -> ../../vda2
lrwxrwxrwx. 1 0 0  10 May 22 12:42 virtio-pci-0000:05:00.0-part3 -> ../../vda3

/dev/disk/by-uuid:
total 0
drwxr-xr-x. 2 0 0 100 May 22 12:42 .
drwxr-xr-x. 7 0 0 140 May 22 12:42 ..
lrwxrwxrwx. 1 0 0  10 May 22 12:42 133f2d41-0b08-46a6-b567-d76e9ab48b31 -> ../../dm-0
lrwxrwxrwx. 1 0 0  10 May 22 12:42 d29ca59d-b179-4715-a503-13d626f84423 -> ../../vda2
lrwxrwxrwx. 1 0 0  10 May 22 12:42 eb637fcc-d119-438f-bfe4-6e56abfc3aed -> ../../dm-1

/dev/mapper:
total 0
drwxr-xr-x.  2 0 0     100 May 22 12:42 .
drwxr-xr-x. 21 0 0    3380 May 22 12:42 ..
crw-------.  1 0 0 10, 236 May 22 12:42 control
lrwxrwxrwx.  1 0 0       7 May 22 12:42 rhel_bootp--73--213--208-root -> ../dm-0
lrwxrwxrwx.  1 0 0       7 May 22 12:42 rhel_bootp--73--213--208-swap -> ../dm-1

/etc:
total 1068
drwxr-xr-x. 92 0   0   8192 Jul 10 12:13 .
dr-xr-xr-x. 18 0   0    235 Apr 23 14:51 ..
-rw-------.  1 0   0      0 Apr 23 14:51 .pwd.lock
-rw-r--r--.  1 0   0    208 Apr 23 14:51 .updated
-rw-r--r--.  1 0   0   5923 Nov 26  2024 DIR_COLORS
-rw-r--r--.  1 0   0   6005 Nov 26  2024 DIR_COLORS.lightbgcolor
-rw-r--r--.  1 0   0     94 Oct 29  2024 GREP_COLORS
drwxr-xr-x.  7 0   0    134 Apr 23 14:51 NetworkManager
drwxr-xr-x.  6 0   0     70 Apr 23 14:53 X11
-rw-r--r--.  1 0   0     16 Apr 23 14:53 adjtime
-rw-r--r--.  1 0   0   1529 Nov 29  2023 aliases
drwxr-xr-x.  2 0   0   4096 Apr 23 14:51 alternatives
-rw-r--r--.  1 0   0    541 Dec 11  2024 anacrontab
drwxr-x---.  4 0   0    100 Apr 23 14:51 audit
drwxr-xr-x.  3 0   0   4096 Apr 23 14:52 authselect
drwxr-xr-x.  2 0   0     38 Apr 23 14:51 bash_completion.d
-rw-r--r--.  1 0   0   2709 Nov 29  2023 bashrc
drwxr-xr-x.  2 0   0      6 Mar 10 08:00 binfmt.d
-rw-r--r--.  1 0   0   1646 Apr 23 14:53 chrony.conf
drwxr-xr-x.  2 0   0     26 Apr 23 14:51 cifs-utils
drwx------.  2 0   0      6 Mar 10 08:00 credstore
drwx------.  2 0   0      6 Mar 10 08:00 credstore.encrypted
drwxr-xr-x.  2 0   0     21 Apr 23 14:51 cron.d
drwxr-xr-x.  2 0   0      6 Oct 29  2024 cron.daily
-rw-r--r--.  1 0   0      0 Dec 11  2024 cron.deny
drwxr-xr-x.  2 0   0     22 Oct 29  2024 cron.hourly
drwxr-xr-x.  2 0   0      6 Oct 29  2024 cron.monthly
drwxr-xr-x.  2 0   0      6 Oct 29  2024 cron.weekly
-rw-r--r--.  1 0   0    451 Oct 29  2024 crontab
drwxr-xr-x.  6 0   0     81 Apr 23 14:51 crypto-policies
-rw-------.  1 0   0      0 Apr 23 14:50 crypttab
-rw-r--r--.  1 0   0   1401 Nov 29  2023 csh.cshrc
-rw-r--r--.  1 0   0   1569 Nov 29  2023 csh.login
drwxr-xr-x.  4 0   0     78 Apr 23 14:51 dbus-1
drwxr-xr-x.  3 0   0     16 Apr 23 14:52 dconf
drwxr-xr-x.  2 0   0     31 Apr 23 14:51 debuginfod
drwxr-xr-x.  2 0   0     33 Apr 23 14:53 default
drwxr-xr-x.  2 0   0     23 Apr 23 14:51 depmod.d
drwxr-xr-x.  3 0   0     24 Apr 23 14:51 dhcp
drwxr-xr-x.  8 0   0    128 Apr 23 14:51 dnf
-rw-r--r--.  1 0   0    117 Mar  6 08:00 dracut.conf
drwxr-xr-x.  2 0   0      6 Mar  6 08:00 dracut.conf.d
-rw-r--r--.  1 0   0      0 Oct 29  2024 environment
-rw-r--r--.  1 0   0   1362 Nov 29  2023 ethertypes
-rw-r--r--.  1 0   0      0 Nov 29  2023 exports
-rw-r--r--.  1 0   0     66 Nov 29  2023 filesystems
drwxr-x---.  8 0   0    119 Apr 23 14:51 firewalld
drwxr-xr-x.  3 0   0     20 Apr 23 14:51 fonts
-rw-r--r--.  1 0   0    615 Apr 23 14:50 fstab
drwxr-xr-x.  2 0   0      6 Oct 29  2024 gcrypt
drwxr-xr-x.  2 0   0      6 Oct 29  2024 gnupg
drwxr-xr-x.  4 0   0     40 Apr 23 14:51 groff
-rw-r--r--.  1 0   0    559 Jul  2 11:06 group
-rw-r--r--.  1 0   0    548 Apr 23 14:53 group-
drwx------.  2 0   0   4096 Apr 23 14:51 grub.d
lrwxrwxrwx.  1 0   0     22 Mar 25 08:00 grub2.cfg -> ../boot/grub2/grub.cfg
----------.  1 0   0    449 Jul  2 11:06 gshadow
----------.  1 0   0    440 Apr 23 14:53 gshadow-
drwxr-xr-x.  3 0   0     20 Apr 23 14:51 gss
-rw-r--r--.  1 0   0      9 Nov 29  2023 host.conf
-rw-r--r--.  1 0   0     24 May 22 12:53 hostname
-rw-r--r--.  1 0   0    384 Nov 29  2023 hosts
-rw-r--r--.  1 0   0    490 Mar 10 08:00 inittab
-rw-r--r--.  1 0   0    943 Nov 29  2023 inputrc
drwxr-xr-x.  2 0   0   4096 May 22 12:39 insights-client
-rw-r--r--.  1 0   0     20 Mar 17 08:00 issue
drwxr-xr-x.  2 0   0      6 Mar 17 08:00 issue.d
-rw-r--r--.  1 0   0     19 Mar 17 08:00 issue.net
drwxr-xr-x.  4 0   0     33 Apr 23 14:51 kdump
-rw-r--r--.  1 0   0   8684 Apr 23 14:51 kdump.conf
drwxr-xr-x.  3 0   0     38 Apr 23 14:53 kernel
drwxr-xr-x.  3 0   0     17 Apr 23 14:51 keys
drwxr-xr-x.  2 0   0      6 Oct 29  2024 keyutils
-rw-r--r--.  1 0   0    880 Jan 29 08:00 krb5.conf
drwxr-xr-x.  2 0   0     55 Apr 23 14:51 krb5.conf.d
-rw-r--r--.  1 0   0  14107 Jul  2 11:06 ld.so.cache
-rw-r--r--.  1 0   0     28 Feb  1  2024 ld.so.conf
drwxr-xr-x.  2 0   0      6 Jan 24 08:00 ld.so.conf.d
-rw-r-----.  1 0   0    191 Jan  7  2025 libaudit.conf
drwxr-xr-x.  2 0   0     35 Apr 23 14:51 libnl
drwxr-xr-x.  2 0   0     62 Apr 23 14:51 libssh
-rw-r--r--.  1 0   0     19 Apr 23 14:53 locale.conf
lrwxrwxrwx.  1 0   0     35 Apr 23 14:53 localtime -> ../usr/share/zoneinfo/Asia/Shanghai
-rw-r--r--.  1 0   0   8888 Nov  4  2024 login.defs
-rw-r--r--.  1 0   0    493 Jul  6  2021 logrotate.conf
drwxr-xr-x.  2 0   0    166 Apr 23 14:51 logrotate.d
drwxr-xr-x.  7 0   0    115 Apr 23 14:51 lvm
-r--r--r--.  1 0   0     33 Apr 23 14:51 machine-id
-rw-r--r--.  1 0   0    110 Oct 29  2024 magic
-rw-r--r--.  1 0   0   5122 Jan 15 08:00 makedumpfile.conf.sample
-rw-r--r--.  1 0   0   5242 Oct 29  2024 man_db.conf
drwxr-xr-x.  3 0   0     32 Apr 23 14:51 microcode_ctl
-rw-r--r--.  1 0   0    782 Oct 29  2024 mke2fs.conf
drwxr-xr-x.  2 0   0   4096 Apr 23 14:51 modprobe.d
drwxr-xr-x.  2 0   0      6 Mar 10 08:00 modules-load.d
-rw-r--r--.  1 0   0      0 Nov 29  2023 motd
drwxr-xr-x.  2 0   0      6 May 22 12:39 motd.d
lrwxrwxrwx.  1 0   0     19 Feb 13 08:00 mtab -> ../proc/self/mounts
-rw-r--r--.  1 0   0     58 Nov 29  2023 networks
drwx------.  3 0   0     66 Apr 23 14:51 nftables
lrwxrwxrwx.  1 0   0     29 Apr 23 14:52 nsswitch.conf -> /etc/authselect/nsswitch.conf
drwxr-xr-x.  2 0   0     35 Apr 23 14:50 nvme
drwxr-xr-x.  3 0   0     36 Apr 23 14:51 openldap
drwxr-xr-x.  2 0   0      6 Oct 29  2024 opt
lrwxrwxrwx.  1 0   0     21 Mar 17 08:00 os-release -> ../usr/lib/os-release
drwxr-xr-x.  2 0   0   4096 Apr 23 14:52 pam.d
-rw-r--r--.  1 0   0   1279 Jul  2 11:06 passwd
-rw-r--r--.  1 0   0   1213 Apr 23 14:53 passwd-
drwxr-xr-x. 24 0   0   4096 Jul  2 11:06 pcp
-rw-r--r--.  1 0   0   7338 Mar 31 08:00 pcp.conf
-rw-r--r--.  1 0   0   6662 Mar 31 08:00 pcp.env
drwxr-xr-x.  3 0   0     21 Apr 23 14:51 pkcs11
drwxr-xr-x.  3 0   0     27 Jul  2 11:05 pkgconfig
drwxr-xr-x. 13 0   0    176 May 22 12:38 pki
drwxr-xr-x.  5 0   0     52 Apr 23 14:51 pm
drwxr-xr-x.  5 0   0     72 Apr 23 14:51 polkit-1
drwxr-xr-x.  2 0   0      6 Oct 29  2024 popt.d
-rw-r--r--.  1 0   0    233 Nov 29  2023 printcap
-rw-r--r--.  1 0   0   1982 Nov 29  2023 profile
drwxr-xr-x.  2 0   0   4096 Apr 23 14:51 profile.d
-rw-r--r--.  1 0   0   6714 Nov 29  2023 protocols
drwxr-xr-x.  3 0   0     50 Apr 23 14:51 qemu-ga
drwxr-xr-x.  3 0   0     36 Apr 23 14:51 rc.d
lrwxrwxrwx.  1 0   0     13 Mar 10 08:00 rc.local -> rc.d/rc.local
drwxr-xr-x.  2 0   0     25 Oct 29  2024 reader.conf.d
-rw-r--r--.  1 0   0     49 Mar 17 08:00 redhat-release
-rw-r--r--.  1 0   0   1787 Oct 29  2024 request-key.conf
drwxr-xr-x.  2 0   0      6 Oct 29  2024 request-key.d
-rw-r--r--.  1 0   0    105 Jul 10 12:13 resolv.conf
drwxr-xr-x.  6 0   0     84 May 22 12:38 rhsm
-rw-r--r--.  1 0   0   1634 Jan 31  2024 rpc
drwxr-xr-x.  2 0   0      6 Feb  7 08:00 rpm
-rw-r--r--.  1 0   0   3409 Dec  5  2024 rsyslog.conf
drwxr-xr-x.  2 0   0      6 Dec  5  2024 rsyslog.d
drwxr-xr-x.  2 0   0     35 Apr 23 14:51 rwtab.d
drwxr-xr-x.  2 0   0     23 Jul  2 11:06 sasl2
drwxr-xr-x.  5 0   0   4096 Apr 23 14:51 security
drwxr-xr-x.  3 0   0     57 Apr 23 14:51 selinux
-rw-r--r--.  1 0   0 701707 Nov 29  2023 services
-rw-r--r--.  1 0   0    216 Jan 31 08:00 sestatus.conf
----------.  1 0   0    669 Jul  2 11:06 shadow
----------.  1 0   0    650 May 22 12:57 shadow-
-rw-r--r--.  1 0   0     44 Nov 29  2023 shells
drwxr-xr-x.  2 0   0     62 Apr 23 14:51 skel
drwxr-xr-x.  4 0   0   4096 Apr 23 16:02 ssh
drwxr-xr-x.  2 0   0     91 Apr 23 14:51 ssl
drwxr-x---.  4 0 995     31 Apr 23 14:51 sssd
drwxr-xr-x.  2 0   0      6 Oct 29  2024 statetab.d
-rw-r--r--.  1 0   0      0 Nov 29  2023 subgid
-rw-r--r--.  1 0   0      0 Nov 29  2023 subuid
-rw-r-----.  1 0   0   3181 Oct 29  2024 sudo-ldap.conf
-rw-r-----.  1 0   0   4339 Oct 29  2024 sudo.conf
-r--r-----.  1 0   0   4328 Oct 29  2024 sudoers
drwxr-x---.  2 0   0      6 Oct 29  2024 sudoers.d
drwxr-xr-x.  3 0   0     24 Apr 23 14:51 swid
drwxr-xr-x.  2 0   0   4096 Jul  2 11:06 sysconfig
-rw-r--r--.  1 0   0    449 Mar 10 08:00 sysctl.conf
drwxr-xr-x.  2 0   0     28 Apr 23 14:51 sysctl.d
lrwxrwxrwx.  1 0   0     14 Mar 17 08:00 system-release -> redhat-release
-rw-r--r--.  1 0   0     42 Mar 17 08:00 system-release-cpe
drwxr-xr-x.  5 0   0     47 Apr 23 14:51 systemd
drwxr-xr-x.  2 0   0      6 Oct 29  2024 terminfo
drwxr-xr-x.  2 0   0      6 Mar 10 08:00 tmpfiles.d
drwxr-xr-x.  3 0   0     51 Apr 23 14:51 tpm2-tss
drwxr-xr-x.  4 0   0     51 Apr 23 16:02 udev
-rw-r--r--.  1 0   0     28 Apr 23 14:53 vconsole.conf
-rw-r--r--.  1 0   0   1183 Jan 27 08:00 virc
-rw-r--r--.  1 0   0    817 Oct 29  2024 xattr.conf
drwxr-xr-x.  4 0   0     38 Apr 23 14:51 xdg
drwxr-xr-x.  2 0   0     25 Apr 23 14:51 yggdrasil
drwxr-xr-x.  2 0   0     25 Apr 23 14:51 yggdrasil-worker-package-manager
drwxr-xr-x.  2 0   0     57 Apr 23 14:51 yum
lrwxrwxrwx.  1 0   0     12 Feb  7 08:00 yum.conf -> dnf/dnf.conf
drwxr-xr-x.  2 0   0     25 May 22 12:39 yum.repos.d

/etc/crypto-policies:
total 20
drwxr-xr-x.  6 0 0   81 Apr 23 14:51 .
drwxr-xr-x. 92 0 0 8192 Jul 10 12:13 ..
drwxr-xr-x.  2 0 0 4096 Apr 23 14:53 back-ends
-rw-r--r--.  1 0 0    8 Apr 23 14:51 config
drwxr-xr-x.  2 0 0    6 Feb 14 08:00 local.d
drwxr-xr-x.  3 0 0   21 Apr 23 14:51 policies
drwxr-xr-x.  2 0 0   40 Apr 23 14:53 state

/etc/crypto-policies/back-ends:
total 4
drwxr-xr-x. 2 0 0 4096 Apr 23 14:53 .
drwxr-xr-x. 6 0 0   81 Apr 23 14:51 ..
lrwxrwxrwx. 1 0 0   43 Apr 23 14:53 bind.config -> /usr/share/crypto-policies/DEFAULT/bind.txt
lrwxrwxrwx. 1 0 0   45 Apr 23 14:53 gnutls.config -> /usr/share/crypto-policies/DEFAULT/gnutls.txt
lrwxrwxrwx. 1 0 0   43 Apr 23 14:53 java.config -> /usr/share/crypto-policies/DEFAULT/java.txt
lrwxrwxrwx. 1 0 0   43 Apr 23 14:53 krb5.config -> /usr/share/crypto-policies/DEFAULT/krb5.txt
lrwxrwxrwx. 1 0 0   48 Apr 23 14:53 libreswan.config -> /usr/share/crypto-policies/DEFAULT/libreswan.txt
lrwxrwxrwx. 1 0 0   45 Apr 23 14:53 libssh.config -> /usr/share/crypto-policies/DEFAULT/libssh.txt
lrwxrwxrwx. 1 0 0   42 Apr 23 14:53 nss.config -> /usr/share/crypto-policies/DEFAULT/nss.txt
lrwxrwxrwx. 1 0 0   46 Apr 23 14:53 openssh.config -> /usr/share/crypto-policies/DEFAULT/openssh.txt
lrwxrwxrwx. 1 0 0   52 Apr 23 14:53 opensshserver.config -> /usr/share/crypto-policies/DEFAULT/opensshserver.txt
lrwxrwxrwx. 1 0 0   46 Apr 23 14:53 openssl.config -> /usr/share/crypto-policies/DEFAULT/openssl.txt
lrwxrwxrwx. 1 0 0   51 Apr 23 14:53 openssl_fips.config -> /usr/share/crypto-policies/DEFAULT/openssl_fips.txt
lrwxrwxrwx. 1 0 0   49 Apr 23 14:53 opensslcnf.config -> /usr/share/crypto-policies/DEFAULT/opensslcnf.txt
lrwxrwxrwx. 1 0 0   50 Apr 23 14:53 rpm-sequoia.config -> /usr/share/crypto-policies/DEFAULT/rpm-sequoia.txt
lrwxrwxrwx. 1 0 0   46 Apr 23 14:53 sequoia.config -> /usr/share/crypto-policies/DEFAULT/sequoia.txt

/etc/crypto-policies/state:
total 8
drwxr-xr-x. 2 0 0   40 Apr 23 14:53 .
drwxr-xr-x. 6 0 0   81 Apr 23 14:51 ..
-rw-r--r--. 1 0 0 3017 Apr 23 14:53 CURRENT.pol
-rw-r--r--. 1 0 0    8 Apr 23 14:53 current

/etc/dnf/vars:
total 0
drwxr-xr-x. 2 0 0   6 Feb  7 08:00 .
drwxr-xr-x. 8 0 0 128 Apr 23 14:51 ..

/etc/pki/tls/private:
total 0
drwxr-xr-x. 2 0 0   6 Jan 29 08:00 .
drwxr-xr-x. 6 0 0 127 Apr 23 14:51 ..

/etc/selinux/targeted/policy:
total 3212
drwxr-xr-x. 2 0 0      23 Jul  2 11:06 .
drwxr-xr-x. 5 0 0     133 Jul  2 11:06 ..
-rw-r--r--. 1 0 0 3288144 Jul  2 11:06 policy.34

/etc/ssh:
total 580
drwxr-xr-x.  4 0 0   4096 Apr 23 16:02 .
drwxr-xr-x. 92 0 0   8192 Jul 10 12:13 ..
-rw-r--r--.  1 0 0 541716 Feb 18 08:00 moduli
-rw-r--r--.  1 0 0   1916 Feb 18 08:00 ssh_config
drwxr-xr-x.  2 0 0     28 Apr 23 14:51 ssh_config.d
-rw-------.  1 0 0    480 Apr 23 16:02 ssh_host_ecdsa_key
-rw-r--r--.  1 0 0    162 Apr 23 16:02 ssh_host_ecdsa_key.pub
-rw-------.  1 0 0    387 Apr 23 16:02 ssh_host_ed25519_key
-rw-r--r--.  1 0 0     82 Apr 23 16:02 ssh_host_ed25519_key.pub
-rw-------.  1 0 0   2578 Apr 23 16:02 ssh_host_rsa_key
-rw-r--r--.  1 0 0    554 Apr 23 16:02 ssh_host_rsa_key.pub
-rw-------.  1 0 0   3674 Feb 18 08:00 sshd_config
drwx------.  2 0 0     97 Apr 23 14:53 sshd_config.d

/etc/sysconfig:
total 100
drwxr-xr-x.  2 0 0 4096 Jul  2 11:06 .
drwxr-xr-x. 92 0 0 8192 Jul 10 12:13 ..
-rw-r--r--.  1 0 0  112 Apr 23 14:53 anaconda
-rw-r--r--.  1 0 0   50 Nov  6  2024 chronyd
-rw-r--r--.  1 0 0  110 Dec 11  2024 crond
-rw-r--r--.  1 0 0   73 Jan 15 08:00 firewalld
-rw-r--r--.  1 0 0 1399 Mar 19  2024 irqbalance
-rw-r--r--.  1 0 0 2835 Mar  6 08:00 kdump
-rw-r--r--.  1 0 0  185 Apr 23 14:53 kernel
-rw-r--r--.  1 0 0  310 Oct 29  2024 man-db
-rw-r--r--.  1 0 0   22 Apr 23 14:53 network
-rw-------.  1 0 0  364 Nov 15  2024 nftables.conf
-rw-r--r--.  1 0 0 1571 Mar 31 08:00 pmcd
-rw-r--r--.  1 0 0  154 Mar 31 08:00 pmfind
-rw-r--r--.  1 0 0  313 Mar 31 08:00 pmie_timers
-rw-r--r--.  1 0 0 1799 Mar 31 08:00 pmlogger
-rw-r--r--.  1 0 0 1617 Mar 31 08:00 pmlogger_farm
-rw-r--r--.  1 0 0  653 Mar 31 08:00 pmlogger_timers
-rw-r--r--.  1 0 0  454 Mar 31 08:00 pmproxy
-rw-r--r--.  1 0 0 1936 Feb 17 08:00 qemu-ga
-rw-r--r--.  1 0 0 2915 Dec  3  2024 raid-check
-rw-r--r--.  1 0 0  196 Dec  5  2024 rsyslog
-rw-r--r--.  1 0 0    0 Oct 29  2024 run-parts
lrwxrwxrwx.  1 0 0   17 Apr 23 14:51 selinux -> ../selinux/config
-rw-r-----.  1 0 0  384 Feb 18 08:00 sshd

/run/systemd/journal:
total 8
drwxr-xr-x.  3 0 0 180 May 22 12:42 .
drwxr-xr-x. 21 0 0 620 Jul 10 15:29 ..
srw-rw-rw-.  1 0 0   0 May 22 12:42 dev-log
srw-------.  1 0 0   0 May 22 12:42 io.systemd.journal
-rw-r--r--.  1 0 0   8 May 22 12:42 kernel-seqnum
-rw-r--r--.  1 0 0  24 May 22 12:42 seqnum
srw-rw-rw-.  1 0 0   0 May 22 12:42 socket
srw-rw-rw-.  1 0 0   0 May 22 12:42 stdout
drwxr-xr-x.  2 0 0 300 Jul 10 15:29 streams

/usr/lib/udev/rules.d:
total 324
drwxr-xr-x. 2 0 0  4096 Jun 25 17:04 .
drwxr-xr-x. 4 0 0  4096 Apr 23 14:51 ..
-rw-r--r--. 1 0 0   837 Nov  4  2024 00-scsi-sg3_config.rules
-rw-r--r--. 1 0 0   321 Dec  3  2024 01-md-raid-creating.rules
-rw-r--r--. 1 0 0  8519 Feb  4 08:00 10-dm.rules
-rw-r--r--. 1 0 0  2182 Feb  4 08:00 11-dm-lvm.rules
-rw-r--r--. 1 0 0  1443 Jan  9 08:00 11-dm-parts.rules
-rw-r--r--. 1 0 0  2248 Feb  4 08:00 13-dm-disk.rules
-rw-r--r--. 1 0 0   728 Mar 10 08:00 40-elevator.rules
-rw-r--r--. 1 0 0   706 Mar 10 08:00 40-redhat-hotplug.rules
-rw-r--r--. 1 0 0   934 Mar 10 08:00 40-redhat-s390.rules
-rw-r--r--. 1 0 0   490 Mar 10 08:00 40-redhat.rules
-rw-r--r--. 1 0 0   458 Nov  4  2024 40-usb-blacklist.rules
-rw-r--r--. 1 0 0  5209 Mar 10 08:00 50-udev-default.rules
-rw-r--r--. 1 0 0   704 Dec 11  2024 60-autosuspend.rules
-rw-r--r--. 1 0 0   721 Dec 11  2024 60-block.rules
-rw-r--r--. 1 0 0  1071 Dec 11  2024 60-cdrom_id.rules
-rw-r--r--. 1 0 0   637 Dec 11  2024 60-dmi-id.rules
-rw-r--r--. 1 0 0   834 Dec 11  2024 60-drm.rules
-rw-r--r--. 1 0 0  1093 Dec 11  2024 60-evdev.rules
-rw-r--r--. 1 0 0   491 Dec 11  2024 60-fido-id.rules
-rw-r--r--. 1 0 0   379 Dec 11  2024 60-infiniband.rules
-rw-r--r--. 1 0 0   282 Dec 11  2024 60-input-id.rules
-rw-r--r--. 1 0 0   129 Aug 27  2024 60-net.rules
-rw-r--r--. 1 0 0   727 Dec 11  2024 60-persistent-alsa.rules
-rw-r--r--. 1 0 0  3265 Dec 11  2024 60-persistent-input.rules
-rw-r--r--. 1 0 0   411 Dec 11  2024 60-persistent-storage-mtd.rules
-rw-r--r--. 1 0 0  2606 Dec 11  2024 60-persistent-storage-tape.rules
-rw-r--r--. 1 0 0 10463 Mar 10 08:00 60-persistent-storage.rules
-rw-r--r--. 1 0 0  1090 Dec 11  2024 60-persistent-v4l.rules
-rw-r--r--. 1 0 0  1618 Dec 11  2024 60-sensor.rules
-rw-r--r--. 1 0 0  1427 Dec 11  2024 60-serial.rules
-rw-r--r--. 1 0 0   230 Apr 26  2024 60-tpm-udev.rules
-rw-r--r--. 1 0 0  8098 Nov  4  2024 61-scsi-sg3_id.rules
-rw-r--r--. 1 0 0   624 Nov  4  2024 63-fc-wwpn-id.rules
-rw-r--r--. 1 0 0  2631 Dec  3  2024 63-md-raid-arrays.rules
-rw-r--r--. 1 0 0  4270 Nov  4  2024 63-scsi-sg3_symlink.rules
-rw-r--r--. 1 0 0   616 Mar 10 08:00 64-btrfs.rules
-rw-r--r--. 1 0 0   654 Oct 29  2024 64-ext4.rules
-rw-r--r--. 1 0 0  2374 Dec  3  2024 64-md-raid-assembly.rules
-rw-r--r--. 1 0 0   732 Nov  4  2024 65-scsi-cciss_id.rules
-rw-r--r--. 1 0 0  1522 Jan  9 08:00 66-kpartx.rules
-rw-r--r--. 1 0 0   895 Dec  3  2024 66-md-auto-readd.rules
-rw-r--r--. 1 0 0  1142 Jan  9 08:00 68-del-part-nodes.rules
-rw-r--r--. 1 0 0  3657 Feb  4 08:00 69-dm-lvm.rules
-rw-r--r--. 1 0 0   858 Dec  3  2024 69-md-clustered-confirm-device.rules
-rw-r--r--. 1 0 0   280 Dec 11  2024 70-camera.rules
-rw-r--r--. 1 0 0   432 Dec 11  2024 70-joystick.rules
-rw-r--r--. 1 0 0   184 Dec 11  2024 70-memory.rules
-rw-r--r--. 1 0 0   734 Dec 11  2024 70-mouse.rules
-rw-r--r--. 1 0 0   576 Dec 11  2024 70-power-switch.rules
-rw-r--r--. 1 0 0   473 Dec 11  2024 70-touchpad.rules
-rw-r--r--. 1 0 0  3855 Mar 10 08:00 70-uaccess.rules
-rw-r--r--. 1 0 0   403 Jul 24  2006 71-prefixdevname.rules
-rw-r--r--. 1 0 0  3870 Mar 10 08:00 71-seat.rules
-rw-r--r--. 1 0 0   643 Mar 10 08:00 73-seat-late.rules
-rw-r--r--. 1 0 0   512 Dec 11  2024 75-net-description.rules
-rw-r--r--. 1 0 0   174 Dec 11  2024 75-probe_mtd.rules
-rw-r--r--. 1 0 0  4816 Dec 11  2024 78-sound-card.rules
-rw-r--r--. 1 0 0   600 Dec 11  2024 80-drivers.rules
-rw-r--r--. 1 0 0   295 Dec 11  2024 80-net-setup-link.rules
-rw-r--r--. 1 0 0   528 Dec 11  2024 81-net-dhcp.rules
-rw-r--r--. 1 0 0   533 Feb 28 21:55 84-nm-drivers.rules
-rw-r--r--. 1 0 0  2013 Feb 28 21:55 85-nm-unmanaged.rules
-rw-r--r--. 1 0 0   769 Dec 11  2024 90-iocost.rules
-rw-r--r--. 1 0 0   588 Feb 28 21:55 90-nm-thunderbolt.rules
-rw-r--r--. 1 0 0   518 Mar 10 08:00 90-vconsole.rules
-rw-r--r--. 1 0 0   483 Feb  4 08:00 95-dm-notify.rules
-rw-r--r--. 1 0 0   906 Mar  6 08:00 98-kexec.rules
-rw-r--r--. 1 0 0   130 Feb 17 08:00 99-qemu-guest-agent.rules
-rw-r--r--. 1 0 0  5451 Mar 10 08:00 99-systemd.rules
-rw-r--r--. 1 0 0   435 Dec 11  2024 README

/var/lib/pcp/pmns:
total 68
drwxr-xr-x. 2 0 0  4096 Jul  2 11:06 .
drwxr-xr-x. 7 0 0    68 Jul  2 11:06 ..
lrwxrwxrwx. 1 0 0    45 Mar 31 08:00 Make.stdpmid -> ../../../../usr/libexec/pcp/pmns/Make.stdpmid
lrwxrwxrwx. 1 0 0    41 Mar 31 08:00 Makefile -> ../../../../usr/libexec/pcp/pmns/Makefile
lrwxrwxrwx. 1 0 0    40 Mar 31 08:00 Rebuild -> ../../../../usr/libexec/pcp/pmns/Rebuild
-rw-r--r--. 1 0 0 54666 Jul  2 11:06 root
-rw-r--r--. 1 0 0     9 Jul  2 11:06 root.prev
lrwxrwxrwx. 1 0 0    41 Mar 31 08:00 root_bpf -> ../../../../usr/libexec/pcp/pmns/root_bpf
lrwxrwxrwx. 1 0 0    42 Mar 31 08:00 root_jbd2 -> ../../../../usr/libexec/pcp/pmns/root_jbd2
lrwxrwxrwx. 1 0 0    41 Mar 31 08:00 root_kvm -> ../../../../usr/libexec/pcp/pmns/root_kvm
lrwxrwxrwx. 1 0 0    43 Mar 31 08:00 root_linux -> ../../../../usr/libexec/pcp/pmns/root_linux
lrwxrwxrwx. 1 0 0    41 Mar 31 08:00 root_mmv -> ../../../../usr/libexec/pcp/pmns/root_mmv
lrwxrwxrwx. 1 0 0    42 Mar 31 08:00 root_pmcd -> ../../../../usr/libexec/pcp/pmns/root_pmcd
lrwxrwxrwx. 1 0 0    45 Mar 31 08:00 root_pmproxy -> ../../../../usr/libexec/pcp/pmns/root_pmproxy
lrwxrwxrwx. 1 0 0    42 Mar 31 08:00 root_proc -> ../../../../usr/libexec/pcp/pmns/root_proc
lrwxrwxrwx. 1 0 0    42 Mar 31 08:00 root_root -> ../../../../usr/libexec/pcp/pmns/root_root
lrwxrwxrwx. 1 0 0    41 Mar 31 08:00 root_xfs -> ../../../../usr/libexec/pcp/pmns/root_xfs
-rw-r--r--. 1 0 0  3761 Jul  2 11:06 stdpmid
lrwxrwxrwx. 1 0 0    46 Mar 31 08:00 stdpmid.local -> ../../../../usr/libexec/pcp/pmns/stdpmid.local
lrwxrwxrwx. 1 0 0    44 Mar 31 08:00 stdpmid.pcp -> ../../../../usr/libexec/pcp/pmns/stdpmid.pcp

/var/lib/sss/pubconf/krb5.include.d:
total 0
drwxrwxr-x. 2 996 995  6 Feb 12 08:00 .
drwxrwxr-x. 3 996 995 28 Apr 23 14:51 ..

/var/log/audit:
total 1352
drwx------.  2 0 0      23 Apr 23 16:02 .
drwxr-xr-x. 11 0 0    4096 Jul  6 00:03 ..
-rw-------.  1 0 0 1368126 Jul 10 15:29 audit.log

/var/spool/cron:
total 0
drwx------. 2 0 0  6 Dec 11  2024 .
drwxr-xr-x. 7 0 0 68 Apr 23 14:51 ..