total 0
drwxr-xr-x. 3 0 0    0 Jun 13 03:36 .
drwxr-xr-x. 4 0 0    0 Jun 13 03:36 ..
drwxr-xr-x. 2 0 0    0 Jun 13 03:36 power
lrwxrwxrwx. 1 0 0    0 Jun 13 03:36 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Jun 13 03:36 uevent
