/bin/ls: cannot access '/etc/nova/migration': No such file or directory
/bin/ls: cannot access '/etc/pki/ovirt-vmconsole': No such file or directory
/bin/ls: cannot access '/etc/watchdog.d/': No such file or directory
/etc:
total 1072
drwxr-xr-x. 94   0   0   8192 Jun 13 03:36 .
dr-xr-xr-x. 17   0   0    224 Oct 13  2022 ..
-rw-------.  1   0   0      0 Oct 13  2022 .pwd.lock
-rw-r--r--.  1   0   0    208 Oct 13  2022 .updated
-rw-r--r--.  1   0   0   4536 May 31  2022 DIR_COLORS
-rw-r--r--.  1   0   0   5214 May 31  2022 DIR_COLORS.256color
-rw-r--r--.  1   0   0   4618 May 31  2022 DIR_COLORS.lightbgcolor
-rw-r--r--.  1   0   0     94 Aug 12  2018 GREP_COLORS
drwxr-xr-x.  7   0   0    134 Oct 13  2022 NetworkManager
drwxr-xr-x.  2   0   0     48 Oct 13  2022 PackageKit
drwxr-xr-x.  6   0   0     70 Oct 13  2022 X11
-rw-r--r--.  1   0   0     12 Aug 22  2022 adjtime
-rw-r--r--.  1   0   0   1529 May  9  2022 aliases
drwxr-xr-x.  2   0   0    103 Oct 13  2022 alternatives
-rw-r--r--.  1   0   0    541 Jul 11  2022 anacrontab
drwxr-x---.  4   0   0    100 Oct 13  2022 audit
drwxr-xr-x.  3   0   0     46 Oct 13  2022 authselect
drwxr-xr-x.  2   0   0     38 Oct 13  2022 bash_completion.d
-rw-r--r--.  1   0   0   2917 May  9  2022 bashrc
-rw-r--r--.  1   0   0    535 Aug  3  2022 bindresvport.blacklist
drwxr-xr-x.  2   0   0      6 Sep 27  2022 binfmt.d
drwxr-xr-x.  2   0   0      6 Jul 27  2021 chkconfig.d
-rw-r--r--.  1   0   0   1083 Jul 14  2022 chrony.conf
-rw-r-----.  1   0 989    540 Dec 16  2021 chrony.keys
drwxr-xr-x.  2   0   0     26 Oct 13  2022 cifs-utils
drwxr-xr-x.  4   0   0     59 Oct 13  2022 cloud
drwxr-xr-x.  4   0   0     42 Oct 13  2022 cockpit
drwxr-xr-x.  2   0   0     21 Oct 13  2022 cron.d
drwxr-xr-x.  2   0   0     23 Oct 13  2022 cron.daily
-rw-r--r--.  1   0   0      0 Jul 11  2022 cron.deny
drwxr-xr-x.  2   0   0     22 Oct 13  2022 cron.hourly
drwxr-xr-x.  2   0   0      6 Jan  8  2021 cron.monthly
drwxr-xr-x.  2   0   0      6 Jan  8  2021 cron.weekly
-rw-r--r--.  1   0   0    451 Jan  8  2021 crontab
drwxr-xr-x.  6   0   0     81 Oct 13  2022 crypto-policies
-rw-r--r--.  1   0   0   1629 May  9  2022 csh.cshrc
-rw-r--r--.  1   0   0   1087 May  9  2022 csh.login
drwxr-xr-x.  4   0   0     78 Oct 13  2022 dbus-1
drwxr-xr-x.  2   0   0     33 Oct 13  2022 default
drwxr-xr-x.  2   0   0     23 Oct 13  2022 depmod.d
drwxr-x---.  4   0   0     74 Oct 13  2022 dhcp
drwxr-xr-x.  8   0   0    128 Oct 13  2022 dnf
-rw-r--r--.  1   0   0    117 Aug 15  2022 dracut.conf
drwxr-xr-x.  2   0   0      6 Aug 15  2022 dracut.conf.d
-rw-r--r--.  1   0   0      0 May  9  2022 environment
-rw-r--r--.  1   0   0   1362 Sep 10  2018 ethertypes
-rw-r--r--.  1   0   0      0 Sep 10  2018 exports
drwxr-xr-x.  2   0   0      6 Aug  5  2022 exports.d
lrwxrwxrwx.  1   0   0     56 Jul 12  2021 favicon.png -> /usr/share/icons/hicolor/16x16/apps/fedora-logo-icon.png
-rw-r--r--.  1   0   0     66 Sep 10  2018 filesystems
drwxr-xr-x.  3   0   0     38 Oct 13  2022 fonts
-rw-r--r--.  1   0   0    142 Oct 13  2022 fstab
drwxr-xr-x.  2   0   0     25 Oct 13  2022 gcrypt
drwxr-xr-x.  2   0   0      6 Aug  8  2022 gnupg
drwxr-xr-x.  4   0   0     40 Oct 13  2022 groff
-rw-r--r--.  1   0   0    644 Jun 13 03:36 group
-rw-r--r--.  1   0   0    605 Oct 13  2022 group-
drwx------.  2   0   0    288 Oct 13  2022 grub.d
lrwxrwxrwx.  1   0   0     31 Sep  9  2022 grub2-efi.cfg -> ../boot/efi/EFI/redhat/grub.cfg
lrwxrwxrwx.  1   0   0     22 Sep  9  2022 grub2.cfg -> ../boot/grub2/grub.cfg
----------.  1   0   0    517 Jun 13 03:36 gshadow
----------.  1   0   0    482 Oct 13  2022 gshadow-
drwxr-xr-x.  3   0   0     20 Oct 13  2022 gss
drwxr-xr-x.  2   0   0     79 Oct 13  2022 gssproxy
-rw-r--r--.  1   0   0      9 Sep 10  2018 host.conf
-rw-r--r--.  1   0   0     48 Jun 13 03:36 hostname
-rw-r--r--.  1   0   0    158 Sep 10  2018 hosts
-rw-r--r--.  1   0   0   4849 Aug  5  2022 idmapd.conf
lrwxrwxrwx.  1   0   0     11 Jul 27  2021 init.d -> rc.d/init.d
-rw-r--r--.  1   0   0    490 Sep 27  2022 inittab
-rw-r--r--.  1   0   0    942 Sep 10  2018 inputrc
drwxr-xr-x.  2   0   0   4096 Jun 13 03:38 insights-client
drwxr-xr-x.  2   0   0    159 Oct 13  2022 iproute2
-rw-r--r--.  1   0   0     23 Sep 27  2022 issue
drwxr-xr-x.  2   0   0     27 Oct 13  2022 issue.d
-rw-r--r--.  1   0   0     22 Sep 27  2022 issue.net
drwxr-xr-x.  4   0   0     33 Oct 13  2022 kdump
-rw-r--r--.  1   0   0   8550 Oct 13  2022 kdump.conf
drwxr-xr-x.  3   0   0     23 Sep 27  2022 kernel
drwxr-xr-x.  2   0   0      6 Jun 16  2021 keyutils
-rw-r--r--.  1   0   0    812 Jul  7  2022 krb5.conf
drwxr-xr-x.  2   0   0     55 Oct 13  2022 krb5.conf.d
-rw-r--r--.  1   0   0  14523 Jun 13 03:36 ld.so.cache
-rw-r--r--.  1   0   0     28 Aug  1  2018 ld.so.conf
drwxr-xr-x.  2   0   0     82 Oct 13  2022 ld.so.conf.d
-rw-r-----.  1   0   0    191 Jan 23  2022 libaudit.conf
drwxr-xr-x.  2   0   0    246 Oct 13  2022 libibverbs.d
drwxr-xr-x.  2   0   0     35 Oct 13  2022 libnl
drwxr-xr-x.  6   0   0     70 Oct 13  2022 libreport
drwxr-xr-x.  2   0   0     62 Oct 13  2022 libssh
-rw-r--r--.  1   0   0   2391 Jul 23  2015 libuser.conf
-rw-r--r--.  1   0   0     17 Jun 13 03:36 locale.conf
lrwxrwxrwx.  1   0   0     38 Oct 13  2022 localtime -> ../usr/share/zoneinfo/America/New_York
-rw-r--r--.  1   0   0   2512 Jul 21  2022 login.defs
-rw-r--r--.  1   0   0    438 Feb 19  2018 logrotate.conf
drwxr-xr-x.  2   0   0    125 Oct 13  2022 logrotate.d
-rw-r--r--.  1   0   0     33 Jun 13 03:36 machine-id
-rw-r--r--.  1   0   0    111 Aug 26  2022 magic
-rw-r--r--.  1   0   0   5122 Jul 17  2022 makedumpfile.conf.sample
-rw-r--r--.  1   0   0   5165 Jun 24  2021 man_db.conf
drwxr-xr-x.  3   0   0     32 Oct 13  2022 microcode_ctl
-rw-r--r--.  1   0   0   1108 May 13  2022 mke2fs.conf
drwxr-xr-x.  2   0   0     42 Oct 13  2022 modprobe.d
drwxr-xr-x.  2   0   0      6 Sep 27  2022 modules-load.d
-rw-r--r--.  1   0   0      0 Sep 10  2018 motd
drwxr-xr-x.  2   0   0     44 Jun 13 03:38 motd.d
lrwxrwxrwx.  1   0   0     19 Oct 13  2022 mtab -> ../proc/self/mounts
-rw-r--r--.  1   0   0    767 Aug  3  2022 netconfig
-rw-r--r--.  1   0   0     58 Sep 10  2018 networks
-rw-r--r--.  1   0   0   1231 Aug  5  2022 nfs.conf
-rw-r--r--.  1   0   0   3606 Aug  5  2022 nfsmount.conf
-rw-r--r--.  1   0   0   2215 Oct 13  2022 nsswitch.conf
-rw-r--r--.  1   0   0   2197 Aug 25  2022 nsswitch.conf.bak
drwxr-xr-x.  2   0   0      6 Aug 17  2022 oddjob
-rw-r--r--.  1   0   0   4922 Aug 17  2022 oddjobd.conf
drwxr-xr-x.  2   0   0     70 Oct 13  2022 oddjobd.conf.d
drwxr-xr-x.  3   0   0     36 Oct 13  2022 openldap
drwxr-xr-x.  2   0   0      6 Jun 21  2021 opt
lrwxrwxrwx.  1   0   0     22 Sep 27  2022 os-release -> ..//usr/lib/os-release
drwxr-xr-x.  2   0   0   4096 Oct 13  2022 pam.d
-rw-r--r--.  1   0   0   1483 Jun 13 03:36 passwd
-rw-r--r--.  1   0   0   1483 Jun 13 03:36 passwd-
drwxr-xr-x.  3   0   0     21 Oct 13  2022 pkcs11
drwxr-xr-x. 12   0   0    160 Jun 13 03:36 pki
drwxr-xr-x.  5   0   0     52 Oct 13  2022 pm
drwxr-xr-x.  5   0   0     72 Oct 13  2022 polkit-1
drwxr-xr-x.  2   0   0      6 Jan  7  2021 popt.d
-rw-r--r--.  1   0   0    233 Sep 10  2018 printcap
-rw-r--r--.  1   0   0   2123 May  9  2022 profile
drwxr-xr-x.  2   0   0   4096 Oct 13  2022 profile.d
-rw-r--r--.  1   0   0   6568 Sep 10  2018 protocols
drwxr-xr-x.  3   0   0     50 Oct 13  2022 qemu-ga
drwxr-xr-x.  2   0   0     27 Oct 13  2022 qemu-kvm
drwxr-xr-x. 10   0   0    127 Aug 10  2022 rc.d
lrwxrwxrwx.  1   0   0     13 Sep 27  2022 rc.local -> rc.d/rc.local
lrwxrwxrwx.  1   0   0     10 Jul 27  2021 rc0.d -> rc.d/rc0.d
lrwxrwxrwx.  1   0   0     10 Jul 27  2021 rc1.d -> rc.d/rc1.d
lrwxrwxrwx.  1   0   0     10 Jul 27  2021 rc2.d -> rc.d/rc2.d
lrwxrwxrwx.  1   0   0     10 Jul 27  2021 rc3.d -> rc.d/rc3.d
lrwxrwxrwx.  1   0   0     10 Jul 27  2021 rc4.d -> rc.d/rc4.d
lrwxrwxrwx.  1   0   0     10 Jul 27  2021 rc5.d -> rc.d/rc5.d
lrwxrwxrwx.  1   0   0     10 Jul 27  2021 rc6.d -> rc.d/rc6.d
-rw-r--r--.  1   0   0     45 Sep 27  2022 redhat-release
-rw-r--r--.  1   0   0   1787 Jun 16  2021 request-key.conf
drwxr-xr-x.  2   0   0     30 Oct 13  2022 request-key.d
-rw-r--r--.  1   0   0    117 Jun 13 03:36 resolv.conf
drwxr-xr-x.  3   0   0     40 Oct 13  2022 rhc
drwxr-xr-x.  6   0   0    104 Jun 13 03:37 rhsm
-rw-r--r--.  1   0   0   1634 Aug  1  2018 rpc
drwxr-xr-x.  2   0   0     25 Sep 14  2022 rpm
-rw-r--r--.  1   0   0   3186 May 16  2022 rsyslog.conf
drwxr-xr-x.  2   0   0     31 Oct 13  2022 rsyslog.d
drwxr-xr-x.  2   0   0     35 Oct 13  2022 rwtab.d
drwxr-xr-x.  2   0   0      6 Feb 17  2022 sasl2
drwxr-xr-x.  7   0   0   4096 Oct 13  2022 security
drwxr-xr-x.  3   0   0     57 Oct 13  2022 selinux
-rw-r--r--.  1   0   0 692252 May  9  2022 services
-rw-r--r--.  1   0   0    216 Jul 15  2022 sestatus.conf
drwxr-xr-x.  2   0   0     33 Oct 13  2022 setroubleshoot
----------.  1   0   0    751 Jun 13 03:36 shadow
----------.  1   0   0    751 Jun 13 03:36 shadow-
-rw-r--r--.  1   0   0     44 Sep 10  2018 shells
drwxr-xr-x.  2   0   0     62 Oct 13  2022 skel
drwxr-xr-x.  6   0   0     86 Oct 13  2022 sos
drwxr-xr-x.  3   0   0    245 Jun 13 03:36 ssh
drwxr-xr-x.  2   0   0     19 Oct 13  2022 ssl
drwx------.  4 996 993     31 Oct 13  2022 sssd
-rw-r--r--.  1   0   0     24 Jun 13 03:36 subgid
-rw-r--r--.  1   0   0      0 Sep 10  2018 subgid-
-rw-r--r--.  1   0   0     24 Jun 13 03:36 subuid
-rw-r--r--.  1   0   0      0 Sep 10  2018 subuid-
-rw-r-----.  1   0   0   3181 Dec  7  2021 sudo-ldap.conf
-rw-r-----.  1   0   0   1786 Dec  7  2021 sudo.conf
-r--r-----.  1   0   0   4328 Dec  7  2021 sudoers
drwxr-x---.  2   0   0     33 Jun 13 03:36 sudoers.d
drwxr-xr-x.  3   0   0     24 Oct 13  2022 swid
drwxr-xr-x.  5   0   0    278 Oct 13  2022 sysconfig
-rw-r--r--.  1   0   0    449 Sep 27  2022 sysctl.conf
drwxr-xr-x.  2   0   0     28 Oct 13  2022 sysctl.d
lrwxrwxrwx.  1   0   0     14 Sep 27  2022 system-release -> redhat-release
-rw-r--r--.  1   0   0     41 Sep 27  2022 system-release-cpe
drwxr-xr-x.  4   0   0    150 Oct 13  2022 systemd
-rw-r-----.  1   0  59   7046 Nov  6  2020 tcsd.conf
drwxr-xr-x.  2   0   0      6 May 18  2021 terminfo
drwxr-xr-x.  2   0   0      6 Sep 27  2022 tmpfiles.d
drwxr-xr-x.  3   0   0    136 Oct 13  2022 tuned
drwxr-xr-x.  4   0   0     68 Jun 13 03:36 udev
drwxr-xr-x.  2   0   0     45 Oct 13  2022 unbound
-rw-r--r--.  1   0   0   1204 Jun 14  2022 virc
-rw-r--r--.  1   0   0    642 Dec  9  2016 xattr.conf
drwxr-xr-x.  4   0   0     38 Oct 13  2022 xdg
drwxr-xr-x.  2   0   0      6 Jun 21  2021 xinetd.d
drwxr-xr-x.  2   0   0     57 Oct 13  2022 yum
lrwxrwxrwx.  1   0   0     12 Jul 19  2022 yum.conf -> dnf/dnf.conf
drwxr-xr-x.  2   0   0     25 Jun 13 03:37 yum.repos.d

/etc/cloud/cloud.cfg.d:
total 8
drwxr-xr-x. 2 0 0   42 Oct 13  2022 .
drwxr-xr-x. 4 0 0   59 Oct 13  2022 ..
-rw-r--r--. 1 0 0 2070 Feb 15  2022 05_logging.cfg
-rw-r--r--. 1 0 0  167 Feb 15  2022 README

/etc/pki/tls/certs:
total 0
drwxr-xr-x. 2 0 0  54 Oct 13  2022 .
drwxr-xr-x. 5 0 0 104 Oct 13  2022 ..
lrwxrwxrwx. 1 0 0  49 Jul 28  2022 ca-bundle.crt -> /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem
lrwxrwxrwx. 1 0 0  55 Jul 28  2022 ca-bundle.trust.crt -> /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt

/etc/pki/tls/private:
total 0
drwxr-xr-x. 2 0 0   6 Jul  7  2022 .
drwxr-xr-x. 5 0 0 104 Oct 13  2022 ..

/etc/rc.d/init.d:
total 24
drwxr-xr-x.  2 0 0    37 Oct 13  2022 .
drwxr-xr-x. 10 0 0   127 Aug 10  2022 ..
-rw-r--r--.  1 0 0  1161 Sep 27  2022 README
-rw-r--r--.  1 0 0 18434 Aug 10  2022 functions

/etc/selinux/targeted/policy:
total 8372
drwxr-xr-x. 2 0 0      23 Oct 13  2022 .
drwxr-xr-x. 5 0 0     133 Oct 13  2022 ..
-rw-r--r--. 1 0 0 8572186 Oct 13  2022 policy.31

/etc/sysconfig:
total 60
drwxr-xr-x.  5 0 0  278 Oct 13  2022 .
drwxr-xr-x. 94 0 0 8192 Jun 13 03:36 ..
-rw-r--r--.  1 0 0   46 Jul 14  2022 chronyd
drwxr-xr-x.  2 0 0    6 Aug 10  2022 console
-rw-r--r--.  1 0 0  150 Sep 30  2022 cpupower
-rw-r--r--.  1 0 0  110 Jul 11  2022 crond
lrwxrwxrwx.  1 0 0   15 Sep  9  2022 grub -> ../default/grub
-rw-r--r--.  1 0 0  903 Jul 19  2022 irqbalance
-rw-r--r--.  1 0 0 2497 Jul 17  2022 kdump
-rw-r--r--.  1 0 0   39 Oct 13  2022 kernel
-rw-r--r--.  1 0 0  310 Jun 24  2021 man-db
drwxr-xr-x.  2 0 0    6 Aug 10  2022 modules
-rw-r--r--.  1 0 0  102 Jun 13 03:36 network
drwxr-xr-x.  2 0 0   24 Jun 13 03:36 network-scripts
-rw-r--r--.  1 0 0  911 Sep 20  2022 qemu-ga
-rw-r--r--.  1 0 0   73 Aug  4  2022 rpcbind
-rw-r--r--.  1 0 0  196 May 16  2022 rsyslog
-rw-r--r--.  1 0 0    0 Jan  8  2021 run-parts
lrwxrwxrwx.  1 0 0   17 Oct 13  2022 selinux -> ../selinux/config
-rw-r-----.  1 0 0  591 Jun 29  2022 sshd
