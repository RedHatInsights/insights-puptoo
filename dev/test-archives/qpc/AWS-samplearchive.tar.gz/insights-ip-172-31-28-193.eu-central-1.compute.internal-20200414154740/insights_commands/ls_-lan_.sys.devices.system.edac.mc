total 0
drwxr-xr-x. 3 0 0     0 Apr 14 15:42 .
drwxr-xr-x. 4 0 0     0 Apr 14 15:42 ..
drwxr-xr-x. 2 0 0     0 Apr 14 15:47 power
lrwxrwxrwx. 1 0 0     0 Apr 14 15:42 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 65536 Apr 14 15:42 uevent