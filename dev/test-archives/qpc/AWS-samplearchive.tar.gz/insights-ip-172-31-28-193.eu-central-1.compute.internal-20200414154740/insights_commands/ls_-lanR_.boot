/boot:
total 88864
dr-xr-xr-x.  7 0 0     4096 Sep 20  2019 .
dr-xr-xr-x. 18 0 0      236 Sep 20  2019 ..
-rw-r--r--.  1 0 0      173 Sep 15  2019 .vmlinuz-4.18.0-80.11.2.el8_0.aarch64.hmac
-rw-------.  1 0 0  3367197 Sep 15  2019 System.map-4.18.0-80.11.2.el8_0.aarch64
-rw-r--r--.  1 0 0   133607 Sep 15  2019 config-4.18.0-80.11.2.el8_0.aarch64
drwxr-xr-x.  9 0 0       98 Sep 20  2019 dtb-4.18.0-80.11.2.el8_0.aarch64
drwx------.  3 0 0    16384 Jan  1  1970 efi
drwxr-xr-x.  2 0 0       39 Sep 20  2019 grub
drwx------.  2 0 0       21 Sep 20  2019 grub2
-rw-------.  1 0 0 41027959 Sep 20  2019 initramfs-0-rescue-2d44f66e10bb42bf9e7742eb858ce6a3.img
-rw-------.  1 0 0 31435360 Sep 20  2019 initramfs-4.18.0-80.11.2.el8_0.aarch64.img
drwxr-xr-x.  3 0 0       21 Sep 20  2019 loader
-rwxr-xr-x.  1 0 0  7497133 Sep 20  2019 vmlinuz-0-rescue-2d44f66e10bb42bf9e7742eb858ce6a3
-rwxr-xr-x.  1 0 0  7497133 Sep 15  2019 vmlinuz-4.18.0-80.11.2.el8_0.aarch64

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64:
total 4
drwxr-xr-x. 9 0 0   98 Sep 20  2019 .
dr-xr-xr-x. 7 0 0 4096 Sep 20  2019 ..
drwxr-xr-x. 2 0 0  112 Sep 20  2019 amd
drwxr-xr-x. 2 0 0   51 Sep 20  2019 apm
drwxr-xr-x. 2 0 0  244 Sep 20  2019 arm
drwxr-xr-x. 4 0 0   40 Sep 20  2019 broadcom
drwxr-xr-x. 2 0 0   55 Sep 20  2019 cavium
drwxr-xr-x. 2 0 0  150 Sep 20  2019 hisilicon
drwxr-xr-x. 2 0 0  217 Sep 20  2019 qcom

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/amd:
total 32
drwxr-xr-x. 2 0 0  112 Sep 20  2019 .
drwxr-xr-x. 9 0 0   98 Sep 20  2019 ..
-rw-r--r--. 1 0 0 8097 Sep 15  2019 amd-overdrive-rev-b0.dtb
-rw-r--r--. 1 0 0 8089 Sep 15  2019 amd-overdrive-rev-b1.dtb
-rw-r--r--. 1 0 0 5927 Sep 15  2019 amd-overdrive.dtb
-rw-r--r--. 1 0 0 8109 Sep 15  2019 husky.dtb

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/apm:
total 40
drwxr-xr-x. 2 0 0    51 Sep 20  2019 .
drwxr-xr-x. 9 0 0    98 Sep 20  2019 ..
-rw-r--r--. 1 0 0 16284 Sep 15  2019 apm-merlin.dtb
-rw-r--r--. 1 0 0 21993 Sep 15  2019 apm-mustang.dtb

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/arm:
total 128
drwxr-xr-x. 2 0 0   244 Sep 20  2019 .
drwxr-xr-x. 9 0 0    98 Sep 20  2019 ..
-rw-r--r--. 1 0 0  5358 Sep 15  2019 foundation-v8-gicv3-psci.dtb
-rw-r--r--. 1 0 0  5411 Sep 15  2019 foundation-v8-gicv3.dtb
-rw-r--r--. 1 0 0  5235 Sep 15  2019 foundation-v8-psci.dtb
-rw-r--r--. 1 0 0  5288 Sep 15  2019 foundation-v8.dtb
-rw-r--r--. 1 0 0 24493 Sep 15  2019 juno-r1.dtb
-rw-r--r--. 1 0 0 24493 Sep 15  2019 juno-r2.dtb
-rw-r--r--. 1 0 0 23345 Sep 15  2019 juno.dtb
-rw-r--r--. 1 0 0  8545 Sep 15  2019 rtsm_ve-aemv8a.dtb
-rw-r--r--. 1 0 0 11452 Sep 15  2019 vexpress-v2f-1xv7-ca53x2.dtb

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/broadcom:
total 0
drwxr-xr-x. 4 0 0 40 Sep 20  2019 .
drwxr-xr-x. 9 0 0 98 Sep 20  2019 ..
drwxr-xr-x. 2 0 0 44 Sep 20  2019 northstar2
drwxr-xr-x. 2 0 0 50 Sep 20  2019 stingray

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/broadcom/northstar2:
total 32
drwxr-xr-x. 2 0 0    44 Sep 20  2019 .
drwxr-xr-x. 4 0 0    40 Sep 20  2019 ..
-rw-r--r--. 1 0 0 15446 Sep 15  2019 ns2-svk.dtb
-rw-r--r--. 1 0 0 14948 Sep 15  2019 ns2-xmc.dtb

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/broadcom/stingray:
total 48
drwxr-xr-x. 2 0 0    50 Sep 20  2019 .
drwxr-xr-x. 4 0 0    40 Sep 20  2019 ..
-rw-r--r--. 1 0 0 21390 Sep 15  2019 bcm958742k.dtb
-rw-r--r--. 1 0 0 20963 Sep 15  2019 bcm958742t.dtb

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/cavium:
total 12
drwxr-xr-x. 2 0 0   55 Sep 20  2019 .
drwxr-xr-x. 9 0 0   98 Sep 20  2019 ..
-rw-r--r--. 1 0 0 7132 Sep 15  2019 thunder-88xx.dtb
-rw-r--r--. 1 0 0 2745 Sep 15  2019 thunder2-99xx.dtb

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/hisilicon:
total 152
drwxr-xr-x. 2 0 0   150 Sep 20  2019 .
drwxr-xr-x. 9 0 0    98 Sep 20  2019 ..
-rw-r--r--. 1 0 0 34274 Sep 15  2019 hi3660-hikey960.dtb
-rw-r--r--. 1 0 0 14184 Sep 15  2019 hi3798cv200-poplar.dtb
-rw-r--r--. 1 0 0 38113 Sep 15  2019 hi6220-hikey.dtb
-rw-r--r--. 1 0 0  7035 Sep 15  2019 hip05-d02.dtb
-rw-r--r--. 1 0 0 16413 Sep 15  2019 hip06-d03.dtb
-rw-r--r--. 1 0 0 30002 Sep 15  2019 hip07-d05.dtb

/boot/dtb-4.18.0-80.11.2.el8_0.aarch64/qcom:
total 176
drwxr-xr-x. 2 0 0   217 Sep 20  2019 .
drwxr-xr-x. 9 0 0    98 Sep 20  2019 ..
-rw-r--r--. 1 0 0 44676 Sep 15  2019 apq8016-sbc.dtb
-rw-r--r--. 1 0 0 32202 Sep 15  2019 apq8096-db820c.dtb
-rw-r--r--. 1 0 0  8722 Sep 15  2019 ipq8074-hk01.dtb
-rw-r--r--. 1 0 0 35975 Sep 15  2019 msm8916-mtp.dtb
-rw-r--r--. 1 0 0  9582 Sep 15  2019 msm8992-bullhead-rev-101.dtb
-rw-r--r--. 1 0 0  4003 Sep 15  2019 msm8994-angler-rev-101.dtb
-rw-r--r--. 1 0 0 25172 Sep 15  2019 msm8996-mtp.dtb
-rw-r--r--. 1 0 0  5307 Sep 15  2019 sdm845-mtp.dtb

/boot/efi:
total 24
drwx------. 3 0 0 16384 Jan  1  1970 .
dr-xr-xr-x. 7 0 0  4096 Sep 20  2019 ..
drwx------. 4 0 0  4096 Sep 20  2019 EFI

/boot/efi/EFI:
total 28
drwx------. 4 0 0  4096 Sep 20  2019 .
drwx------. 3 0 0 16384 Jan  1  1970 ..
drwx------. 2 0 0  4096 Sep 20  2019 BOOT
drwx------. 3 0 0  4096 Sep 20  2019 redhat

/boot/efi/EFI/BOOT:
total 1148
drwx------. 2 0 0   4096 Sep 20  2019 .
drwx------. 4 0 0   4096 Sep 20  2019 ..
-rwx------. 1 0 0 857896 Apr 12  2019 BOOTAA64.EFI
-rwx------. 1 0 0 304560 Apr 12  2019 fbaa64.efi

/boot/efi/EFI/redhat:
total 5312
drwx------. 3 0 0    4096 Sep 20  2019 .
drwx------. 4 0 0    4096 Sep 20  2019 ..
-rwx------. 1 0 0     184 Apr 12  2019 BOOTAA64.CSV
drwx------. 2 0 0    4096 Aug 23  2019 fonts
-rwx------. 1 0 0    4813 Sep 20  2019 grub.cfg
-rwx------. 1 0 0 1997240 Aug 23  2019 grubaa64.efi
-rwx------. 1 0 0    1024 Apr 14 15:46 grubenv
-rwx------. 1 0 0  831568 Apr 12  2019 mmaa64.efi
-rwx------. 1 0 0  855408 Apr 12  2019 shim.efi
-rwx------. 1 0 0  857896 Apr 12  2019 shimaa64-redhat.efi
-rwx------. 1 0 0  857896 Apr 12  2019 shimaa64.efi

/boot/efi/EFI/redhat/fonts:
total 8
drwx------. 2 0 0 4096 Aug 23  2019 .
drwx------. 3 0 0 4096 Sep 20  2019 ..

/boot/grub:
total 8
drwxr-xr-x. 2 0 0   39 Sep 20  2019 .
dr-xr-xr-x. 7 0 0 4096 Sep 20  2019 ..
-rw-r--r--. 1 0 0  286 Sep 20  2019 grub.conf
lrwxrwxrwx. 1 0 0    9 Sep 20  2019 menu.lst -> grub.conf

/boot/grub2:
total 4
drwx------. 2 0 0   21 Sep 20  2019 .
dr-xr-xr-x. 7 0 0 4096 Sep 20  2019 ..
lrwxrwxrwx. 1 0 0   25 Aug 23  2019 grubenv -> ../efi/EFI/redhat/grubenv

/boot/loader:
total 4
drwxr-xr-x. 3 0 0   21 Sep 20  2019 .
dr-xr-xr-x. 7 0 0 4096 Sep 20  2019 ..
drwx------. 2 0 0  134 Sep 20  2019 entries

/boot/loader/entries:
total 8
drwx------. 2 0 0 134 Sep 20  2019 .
drwxr-xr-x. 3 0 0  21 Sep 20  2019 ..
-rw-r--r--. 1 0 0 408 Sep 20  2019 2d44f66e10bb42bf9e7742eb858ce6a3-0-rescue.conf
-rw-r--r--. 1 0 0 371 Sep 20  2019 2d44f66e10bb42bf9e7742eb858ce6a3-4.18.0-80.11.2.el8_0.aarch64.conf