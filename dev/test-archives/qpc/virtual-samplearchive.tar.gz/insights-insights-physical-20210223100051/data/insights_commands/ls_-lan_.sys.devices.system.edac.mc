total 0
drwxr-xr-x. 3 0 0    0 Feb 23 05:00 .
drwxr-xr-x. 4 0 0    0 Feb 23 03:54 ..
drwxr-xr-x. 2 0 0    0 Feb 23 03:54 power
lrwxrwxrwx. 1 0 0    0 Feb 23 05:00 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Feb 23 03:54 uevent
