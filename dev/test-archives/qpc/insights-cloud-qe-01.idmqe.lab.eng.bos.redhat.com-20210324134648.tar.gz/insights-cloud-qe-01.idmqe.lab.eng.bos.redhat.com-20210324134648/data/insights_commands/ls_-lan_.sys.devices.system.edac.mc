total 0
drwxr-xr-x.  4 0 0    0 Mar 24 09:46 .
drwxr-xr-x.  4 0 0    0 Dec  6 04:52 ..
drwxr-xr-x. 15 0 0    0 Dec  6 09:53 mc0
drwxr-xr-x.  2 0 0    0 Dec  6 09:53 power
lrwxrwxrwx.  1 0 0    0 Mar 24 09:46 subsystem -> ../../../../bus/edac
-rw-r--r--.  1 0 0 4096 Dec  6 04:52 uevent
