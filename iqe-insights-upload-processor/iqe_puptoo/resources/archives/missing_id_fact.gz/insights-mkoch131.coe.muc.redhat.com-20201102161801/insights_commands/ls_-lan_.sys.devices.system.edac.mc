total 0
drwxr-xr-x 3 0 0    0 Sep 16 11:32 .
drwxr-xr-x 4 0 0    0 Sep 16 11:32 ..
drwxr-xr-x 2 0 0    0 Sep 16 11:33 power
lrwxrwxrwx 1 0 0    0 Sep 16 11:32 subsystem -> ../../../../bus/edac
-rw-r--r-- 1 0 0 4096 Sep 16 11:32 uevent