/bin/ls: cannot access '/dev/disk/by-label': No such file or directory
/bin/ls: cannot access '/dev/oracleasm/disks': No such file or directory
/bin/ls: cannot access '/etc/watchdog.d': No such file or directory
/bin/ls: cannot access '/usr/share/ipa/ui/js/plugins/idoverride-memberof': No such file or directory
/bin/ls: cannot access '/var/lib/pcp/pmns': No such file or directory
/bin/ls: cannot access '/var/opt/mssql/log': No such file or directory
/bin/ls: cannot access '/var/www': No such file or directory
lrwxrwxrwx.   1   0   0   11 Aug  6  2024 /etc/yum/vars -> ../dnf/vars
lrwxrwxrwx.   1   0   0    6 Nov 30 22:23 /var/run -> ../run

/:
total 28
dr-xr-xr-x.  18 0 0  235 Nov 30 22:23 .
dr-xr-xr-x.  18 0 0  235 Nov 30 22:23 ..
dr-xr-xr-x.   2 0 0    6 Jun 25  2024 afs
lrwxrwxrwx.   1 0 0    7 Jun 25  2024 bin -> usr/bin
dr-xr-xr-x.   5 0 0 4096 Nov 30 22:35 boot
drwxr-xr-x.  21 0 0 3400 Feb 17 17:19 dev
drwxr-xr-x. 136 0 0 8192 Apr  1 23:42 etc
drwxr-xr-x.   3 0 0   17 Nov 30 22:36 home
lrwxrwxrwx.   1 0 0    7 Jun 25  2024 lib -> usr/lib
lrwxrwxrwx.   1 0 0    9 Jun 25  2024 lib64 -> usr/lib64
drwxr-xr-x.   2 0 0    6 Jun 25  2024 media
drwxr-xr-x.   2 0 0    6 Jun 25  2024 mnt
drwxr-xr-x.   2 0 0    6 Jun 25  2024 opt
dr-xr-xr-x. 272 0 0    0 Feb 17 17:19 proc
dr-xr-x---.  14 0 0 4096 Apr  8 19:09 root
drwxr-xr-x.  46 0 0 1260 May 12 15:53 run
lrwxrwxrwx.   1 0 0    8 Jun 25  2024 sbin -> usr/sbin
drwxr-xr-x.   2 0 0    6 Jun 25  2024 srv
dr-xr-xr-x.  13 0 0    0 Feb 17 17:19 sys
drwxrwxrwt.  16 0 0 4096 May 12 15:54 tmp
drwxr-xr-x.  12 0 0  144 Nov 30 22:23 usr
drwxr-xr-x.  20 0 0 4096 Nov 30 22:34 var

/dev:
total 0
drwxr-xr-x. 21 0  0     3400 Feb 17 17:19 .
dr-xr-xr-x. 18 0  0      235 Nov 30 22:23 ..
crw-r--r--.  1 0  0  10, 235 Feb 17 17:19 autofs
drwxr-xr-x.  2 0  0      160 May 12 02:52 block
drwxr-xr-x.  2 0  0       60 Feb 17 17:19 bsg
drwxr-xr-x.  3 0  0       60 Feb 17 17:19 bus
lrwxrwxrwx.  1 0  0        3 Feb 17 17:19 cdrom -> sr0
drwxr-xr-x.  2 0  0     2960 Feb 17 17:19 char
crw--w----.  1 0  5   5,   1 Feb 17 17:19 console
lrwxrwxrwx.  1 0  0       11 Feb 17 17:19 core -> /proc/kcore
drwxr-xr-x.  3 0  0       60 Feb 17 17:19 cpu
crw-------.  1 0  0  10, 124 Feb 17 17:19 cpu_dma_latency
drwxr-xr-x.  7 0  0      140 Feb 17 17:19 disk
brw-rw----.  1 0  6 253,   0 Feb 17 17:19 dm-0
brw-rw----.  1 0  6 253,   1 Feb 17 17:19 dm-1
drwxr-xr-x.  2 0  0       60 Feb 17 17:19 dma_heap
drwxr-xr-x.  3 0  0      100 Feb 17 17:19 dri
crw-rw----.  1 0 39  29,   0 Feb 17 17:19 fb0
lrwxrwxrwx.  1 0  0       13 Feb 17 17:19 fd -> /proc/self/fd
crw-rw-rw-.  1 0  0   1,   7 Feb 17 17:19 full
crw-rw-rw-.  1 0  0  10, 229 Feb 17 17:19 fuse
crw-------.  1 0  0 242,   0 Feb 17 17:19 hidraw0
crw-------.  1 0  0  10, 228 Feb 17 17:19 hpet
drwxr-xr-x.  2 0  0        0 Feb 17 17:19 hugepages
crw-------.  1 0  0  10, 183 Feb 17 17:19 hwrng
lrwxrwxrwx.  1 0  0       12 Feb 17 17:19 initctl -> /run/initctl
drwxr-xr-x.  4 0  0      280 Feb 17 17:19 input
crw-r--r--.  1 0  0   1,  11 Feb 17 17:19 kmsg
crw-rw-rw-.  1 0 36  10, 232 Feb 17 17:19 kvm
lrwxrwxrwx.  1 0  0       28 Feb 17 17:19 log -> /run/systemd/journal/dev-log
crw-rw----.  1 0  6  10, 237 Feb 17 17:19 loop-control
crw-rw----.  1 0  7   6,   0 Feb 17 17:19 lp0
crw-rw----.  1 0  7   6,   1 Feb 17 17:19 lp1
crw-rw----.  1 0  7   6,   2 Feb 17 17:19 lp2
crw-rw----.  1 0  7   6,   3 Feb 17 17:19 lp3
drwxr-xr-x.  2 0  0      100 Feb 17 17:19 mapper
crw-------.  1 0  0  10, 227 Feb 17 17:19 mcelog
crw-r-----.  1 0  9   1,   1 Feb 17 17:19 mem
drwxrwxrwt.  2 0  0       40 Feb 17 17:19 mqueue
drwxr-xr-x.  2 0  0       60 Feb 17 17:19 net
crw-rw-rw-.  1 0  0   1,   3 Feb 17 17:19 null
crw-------.  1 0  0  10, 144 Feb 17 17:19 nvram
crw-r-----.  1 0  9   1,   4 Feb 17 17:19 port
crw-------.  1 0  0 108,   0 Feb 17 17:19 ppp
crw-rw-rw-.  1 0  5   5,   2 May 12 15:53 ptmx
drwxr-xr-x.  2 0  0        0 Feb 17 17:19 pts
crw-rw-rw-.  1 0  0   1,   8 Feb 17 17:19 random
crw-rw-r--+  1 0  0  10, 242 Feb 17 17:19 rfkill
drwxr-xr-x.  2 0  0       80 Feb 17 17:19 rhel_bootp-73-213-174
lrwxrwxrwx.  1 0  0        4 Feb 17 17:19 rtc -> rtc0
crw-------.  1 0  0 250,   0 Feb 17 17:19 rtc0
crw-rw----+  1 0 11  21,   0 Feb 17 17:19 sg0
drwxrwxrwt.  2 0  0       60 Mar 18 15:55 shm
crw-------.  1 0  0  10, 231 Feb 17 17:19 snapshot
drwxr-xr-x.  2 0  0       80 Feb 17 17:19 snd
brw-rw----+  1 0 11  11,   0 Feb 17 17:19 sr0
lrwxrwxrwx.  1 0  0       15 Feb 17 17:19 stderr -> /proc/self/fd/2
lrwxrwxrwx.  1 0  0       15 Feb 17 17:19 stdin -> /proc/self/fd/0
lrwxrwxrwx.  1 0  0       15 Feb 17 17:19 stdout -> /proc/self/fd/1
crw-rw-rw-.  1 0  5   5,   0 Mar 26 14:14 tty
crw--w----.  1 0  5   4,   0 Feb 17 17:19 tty0
crw--w----.  1 0  5   4,   1 Feb 17 17:19 tty1
crw--w----.  1 0  5   4,  10 Feb 17 17:19 tty10
crw--w----.  1 0  5   4,  11 Feb 17 17:19 tty11
crw--w----.  1 0  5   4,  12 Feb 17 17:19 tty12
crw--w----.  1 0  5   4,  13 Feb 17 17:19 tty13
crw--w----.  1 0  5   4,  14 Feb 17 17:19 tty14
crw--w----.  1 0  5   4,  15 Feb 17 17:19 tty15
crw--w----.  1 0  5   4,  16 Feb 17 17:19 tty16
crw--w----.  1 0  5   4,  17 Feb 17 17:19 tty17
crw--w----.  1 0  5   4,  18 Feb 17 17:19 tty18
crw--w----.  1 0  5   4,  19 Feb 17 17:19 tty19
crw--w----.  1 0  5   4,   2 Feb 17 17:19 tty2
crw--w----.  1 0  5   4,  20 Feb 17 17:19 tty20
crw--w----.  1 0  5   4,  21 Feb 17 17:19 tty21
crw--w----.  1 0  5   4,  22 Feb 17 17:19 tty22
crw--w----.  1 0  5   4,  23 Feb 17 17:19 tty23
crw--w----.  1 0  5   4,  24 Feb 17 17:19 tty24
crw--w----.  1 0  5   4,  25 Feb 17 17:19 tty25
crw--w----.  1 0  5   4,  26 Feb 17 17:19 tty26
crw--w----.  1 0  5   4,  27 Feb 17 17:19 tty27
crw--w----.  1 0  5   4,  28 Feb 17 17:19 tty28
crw--w----.  1 0  5   4,  29 Feb 17 17:19 tty29
crw--w----.  1 0  5   4,   3 Feb 17 17:19 tty3
crw--w----.  1 0  5   4,  30 Feb 17 17:19 tty30
crw--w----.  1 0  5   4,  31 Feb 17 17:19 tty31
crw--w----.  1 0  5   4,  32 Feb 17 17:19 tty32
crw--w----.  1 0  5   4,  33 Feb 17 17:19 tty33
crw--w----.  1 0  5   4,  34 Feb 17 17:19 tty34
crw--w----.  1 0  5   4,  35 Feb 17 17:19 tty35
crw--w----.  1 0  5   4,  36 Feb 17 17:19 tty36
crw--w----.  1 0  5   4,  37 Feb 17 17:19 tty37
crw--w----.  1 0  5   4,  38 Feb 17 17:19 tty38
crw--w----.  1 0  5   4,  39 Feb 17 17:19 tty39
crw--w----.  1 0  5   4,   4 Feb 17 17:19 tty4
crw--w----.  1 0  5   4,  40 Feb 17 17:19 tty40
crw--w----.  1 0  5   4,  41 Feb 17 17:19 tty41
crw--w----.  1 0  5   4,  42 Feb 17 17:19 tty42
crw--w----.  1 0  5   4,  43 Feb 17 17:19 tty43
crw--w----.  1 0  5   4,  44 Feb 17 17:19 tty44
crw--w----.  1 0  5   4,  45 Feb 17 17:19 tty45
crw--w----.  1 0  5   4,  46 Feb 17 17:19 tty46
crw--w----.  1 0  5   4,  47 Feb 17 17:19 tty47
crw--w----.  1 0  5   4,  48 Feb 17 17:19 tty48
crw--w----.  1 0  5   4,  49 Feb 17 17:19 tty49
crw--w----.  1 0  5   4,   5 Feb 17 17:19 tty5
crw--w----.  1 0  5   4,  50 Feb 17 17:19 tty50
crw--w----.  1 0  5   4,  51 Feb 17 17:19 tty51
crw--w----.  1 0  5   4,  52 Feb 17 17:19 tty52
crw--w----.  1 0  5   4,  53 Feb 17 17:19 tty53
crw--w----.  1 0  5   4,  54 Feb 17 17:19 tty54
crw--w----.  1 0  5   4,  55 Feb 17 17:19 tty55
crw--w----.  1 0  5   4,  56 Feb 17 17:19 tty56
crw--w----.  1 0  5   4,  57 Feb 17 17:19 tty57
crw--w----.  1 0  5   4,  58 Feb 17 17:19 tty58
crw--w----.  1 0  5   4,  59 Feb 17 17:19 tty59
crw--w----.  1 0  5   4,   6 Feb 17 17:19 tty6
crw--w----.  1 0  5   4,  60 Feb 17 17:19 tty60
crw--w----.  1 0  5   4,  61 Feb 17 17:19 tty61
crw--w----.  1 0  5   4,  62 Feb 17 17:19 tty62
crw--w----.  1 0  5   4,  63 Feb 17 17:19 tty63
crw--w----.  1 0  5   4,   7 Feb 17 17:19 tty7
crw--w----.  1 0  5   4,   8 Feb 17 17:19 tty8
crw--w----.  1 0  5   4,   9 Feb 17 17:19 tty9
crw-rw----.  1 0 18   4,  64 Feb 17 17:19 ttyS0
crw-rw----.  1 0 18   4,  65 Feb 17 17:19 ttyS1
crw-rw----.  1 0 18   4,  66 Feb 17 17:19 ttyS2
crw-rw----.  1 0 18   4,  67 Feb 17 17:19 ttyS3
crw-rw----.  1 0 36  10, 125 Feb 17 17:19 udmabuf
crw-------.  1 0  0  10, 239 Feb 17 17:19 uhid
crw-------.  1 0  0  10, 223 Feb 17 17:19 uinput
crw-rw-rw-.  1 0  0   1,   9 Feb 17 17:19 urandom
crw-------.  1 0  0 244,   0 Feb 17 17:19 usbmon0
crw-------.  1 0  0 244,   1 Feb 17 17:19 usbmon1
crw-------.  1 0  0 244,   2 Feb 17 17:19 usbmon2
crw-------.  1 0  0  10, 126 Feb 17 17:19 userfaultfd
crw-rw----.  1 0  5   7,   0 Feb 17 17:19 vcs
crw-rw----.  1 0  5   7,   1 Feb 17 17:19 vcs1
crw-rw----.  1 0  5   7,   2 Feb 17 17:19 vcs2
crw-rw----.  1 0  5   7,   3 Feb 17 17:19 vcs3
crw-rw----.  1 0  5   7,   4 Feb 17 17:19 vcs4
crw-rw----.  1 0  5   7,   5 Feb 17 17:19 vcs5
crw-rw----.  1 0  5   7,   6 Feb 17 17:19 vcs6
crw-rw----.  1 0  5   7, 128 Feb 17 17:19 vcsa
crw-rw----.  1 0  5   7, 129 Feb 17 17:19 vcsa1
crw-rw----.  1 0  5   7, 130 Feb 17 17:19 vcsa2
crw-rw----.  1 0  5   7, 131 Feb 17 17:19 vcsa3
crw-rw----.  1 0  5   7, 132 Feb 17 17:19 vcsa4
crw-rw----.  1 0  5   7, 133 Feb 17 17:19 vcsa5
crw-rw----.  1 0  5   7, 134 Feb 17 17:19 vcsa6
crw-rw----.  1 0  5   7,  64 Feb 17 17:19 vcsu
crw-rw----.  1 0  5   7,  65 Feb 17 17:19 vcsu1
crw-rw----.  1 0  5   7,  66 Feb 17 17:19 vcsu2
crw-rw----.  1 0  5   7,  67 Feb 17 17:19 vcsu3
crw-rw----.  1 0  5   7,  68 Feb 17 17:19 vcsu4
crw-rw----.  1 0  5   7,  69 Feb 17 17:19 vcsu5
crw-rw----.  1 0  5   7,  70 Feb 17 17:19 vcsu6
brw-rw----.  1 0  6 252,   0 May 12 02:52 vda
brw-rw----.  1 0  6 252,   1 May 12 02:52 vda1
brw-rw----.  1 0  6 252,   2 May 12 02:52 vda2
drwxr-xr-x.  2 0  0       60 Feb 17 17:19 vfio
crw-------.  1 0  0  10, 127 Feb 17 17:19 vga_arbiter
crw-------.  1 0  0  10, 137 Feb 17 17:19 vhci
crw-rw-rw-.  1 0 36  10, 238 Feb 17 17:19 vhost-net
crw-rw-rw-.  1 0 36  10, 241 Feb 17 17:19 vhost-vsock
drwxr-xr-x.  2 0  0       60 Feb 17 17:19 virtio-ports
crw-------.  1 0  0 241,   1 Feb 17 17:19 vport2p1
crw-------.  1 0  0  10, 130 Feb 17 17:19 watchdog
crw-------.  1 0  0 247,   0 Feb 17 17:19 watchdog0
crw-rw-rw-.  1 0  0   1,   5 Feb 17 17:19 zero

/dev/block:
total 0
drwxr-xr-x.  2 0 0  160 May 12 02:52 .
drwxr-xr-x. 21 0 0 3400 Feb 17 17:19 ..
lrwxrwxrwx.  1 0 0    6 Feb 17 17:19 11:0 -> ../sr0
lrwxrwxrwx.  1 0 0    6 May 12 02:52 252:0 -> ../vda
lrwxrwxrwx.  1 0 0    7 May 12 02:52 252:1 -> ../vda1
lrwxrwxrwx.  1 0 0    7 May 12 02:52 252:2 -> ../vda2
lrwxrwxrwx.  1 0 0    7 Feb 17 17:19 253:0 -> ../dm-0
lrwxrwxrwx.  1 0 0    7 Feb 17 17:19 253:1 -> ../dm-1

/dev/disk/by-id:
total 0
drwxr-xr-x. 2 0 0 160 May 12 02:52 .
drwxr-xr-x. 7 0 0 140 Feb 17 17:19 ..
lrwxrwxrwx. 1 0 0   9 Feb 17 17:19 ata-QEMU_DVD-ROM_QM00001 -> ../../sr0
lrwxrwxrwx. 1 0 0  10 Feb 17 17:19 dm-name-rhel_bootp--73--213--174-root -> ../../dm-0
lrwxrwxrwx. 1 0 0  10 Feb 17 17:19 dm-name-rhel_bootp--73--213--174-swap -> ../../dm-1
lrwxrwxrwx. 1 0 0  10 Feb 17 17:19 dm-uuid-LVM-pWBnY4ZC2eBFDDwMyAN1lbdM4NB0fh6oYHI0zw8h6aM4EcMaryUbnd5nKnqbmKff -> ../../dm-0
lrwxrwxrwx. 1 0 0  10 Feb 17 17:19 dm-uuid-LVM-pWBnY4ZC2eBFDDwMyAN1lbdM4NB0fh6opXTH799tg57tB685KA1InSbQUE5TPHOV -> ../../dm-1
lrwxrwxrwx. 1 0 0  10 May 12 02:52 lvm-pv-uuid-z0BsAH-E8vl-5gQz-zt5q-K8KO-gfsH-St1CKt -> ../../vda2

/dev/disk/by-path:
total 0
drwxr-xr-x. 2 0 0 200 May 12 02:52 .
drwxr-xr-x. 7 0 0 140 Feb 17 17:19 ..
lrwxrwxrwx. 1 0 0   9 Feb 17 17:19 pci-0000:00:1f.2-ata-1 -> ../../sr0
lrwxrwxrwx. 1 0 0   9 Feb 17 17:19 pci-0000:00:1f.2-ata-1.0 -> ../../sr0
lrwxrwxrwx. 1 0 0   9 May 12 02:52 pci-0000:04:00.0 -> ../../vda
lrwxrwxrwx. 1 0 0  10 May 12 02:52 pci-0000:04:00.0-part1 -> ../../vda1
lrwxrwxrwx. 1 0 0  10 May 12 02:52 pci-0000:04:00.0-part2 -> ../../vda2
lrwxrwxrwx. 1 0 0   9 May 12 02:52 virtio-pci-0000:04:00.0 -> ../../vda
lrwxrwxrwx. 1 0 0  10 May 12 02:52 virtio-pci-0000:04:00.0-part1 -> ../../vda1
lrwxrwxrwx. 1 0 0  10 May 12 02:52 virtio-pci-0000:04:00.0-part2 -> ../../vda2

/dev/disk/by-uuid:
total 0
drwxr-xr-x. 2 0 0 100 May 12 02:52 .
drwxr-xr-x. 7 0 0 140 Feb 17 17:19 ..
lrwxrwxrwx. 1 0 0  10 Feb 17 17:19 3e1589ff-d231-4703-b343-7b0acb578853 -> ../../dm-0
lrwxrwxrwx. 1 0 0  10 May 12 02:52 4fadf26b-e474-457d-9bc0-874f47648b36 -> ../../vda1
lrwxrwxrwx. 1 0 0  10 Feb 17 17:19 8f595820-e523-4e21-b5e2-826ded1ef286 -> ../../dm-1

/dev/mapper:
total 0
drwxr-xr-x.  2 0 0     100 Feb 17 17:19 .
drwxr-xr-x. 21 0 0    3400 Feb 17 17:19 ..
crw-------.  1 0 0 10, 236 Feb 17 17:19 control
lrwxrwxrwx.  1 0 0       7 Feb 17 17:19 rhel_bootp--73--213--174-root -> ../dm-0
lrwxrwxrwx.  1 0 0       7 Feb 17 17:19 rhel_bootp--73--213--174-swap -> ../dm-1

/etc:
total 1332
drwxr-xr-x. 136   0   0   8192 Apr  1 23:42 .
dr-xr-xr-x.  18   0   0    235 Nov 30 22:23 ..
-rw-------.   1   0   0      0 Nov 30 22:24 .pwd.lock
-rw-r--r--.   1   0   0    208 Nov 30 22:23 .updated
-rw-r--r--.   1   0   0   4673 Aug 16  2024 DIR_COLORS
-rw-r--r--.   1   0   0   4755 Aug 16  2024 DIR_COLORS.lightbgcolor
-rw-r--r--.   1   0   0     94 Aug 10  2021 GREP_COLORS
drwxr-xr-x.   7   0   0    134 Nov 30 22:25 NetworkManager
drwxr-xr-x.   2   0   0     76 Nov 30 22:27 PackageKit
drwxr-xr-x.   2   0   0     25 Nov 30 22:25 UPower
drwxr-xr-x.   7   0   0    121 Nov 30 22:26 X11
drwxr-xr-x.   3   0   0     28 Nov 30 22:24 accountsservice
-rw-r--r--.   1   0   0     16 Nov 30 22:32 adjtime
-rw-r--r--.   1   0   0   1529 Jun 23  2020 aliases
drwxr-xr-x.   3   0   0     65 Nov 30 22:28 alsa
drwxr-xr-x.   2   0   0   4096 Nov 30 22:28 alternatives
-rw-r--r--.   1   0   0    541 Nov 30  2023 anacrontab
-rw-r--r--.   1   0   0    833 Feb 11  2023 appstream.conf
-rw-r--r--.   1   0   0     55 Jun 17  2024 asound.conf
-rw-r--r--.   1   0   0      1 Apr  4  2022 at.deny
drwxr-x---.   4   0   0    100 Nov 30 22:26 audit
drwxr-xr-x.   3   0   0   4096 Nov 30 22:32 authselect
drwxr-xr-x.   4   0   0     71 Nov 30 22:24 avahi
drwxr-xr-x.   2   0   0    124 Nov 30 22:28 bash_completion.d
-rw-r--r--.   1   0   0   2658 Feb  7  2024 bashrc
-rw-r--r--.   1   0   0    535 Jul 30  2024 bindresvport.blacklist
drwxr-xr-x.   2   0   0      6 Sep 10  2024 binfmt.d
drwxr-xr-x.   2   0   0     23 Nov 30 22:24 bluetooth
-rw-r-----.   1   0 985     33 Nov 30 22:26 brlapi.key
drwxr-xr-x.   7   0   0     84 Nov 30 22:26 brltty
-rw-r--r--.   1   0   0  28974 Aug 10  2021 brltty.conf
drwxr-xr-x.   3   0   0     36 Nov 30 22:27 chromium
-rw-r--r--.   1   0   0   1497 Nov 30 22:32 chrony.conf
-rw-r-----.   1   0 982    540 Aug 12  2024 chrony.keys
drwxr-xr-x.   2   0   0     26 Nov 30 22:25 cifs-utils
drwxr-xr-x.   4   0   0     66 Nov 30 22:27 cockpit
drwxr-xr-x.   8   0   0    170 Nov 30 22:42 containers
drwxr-xr-x.   2   0   0     21 Nov 30 22:25 cron.d
drwxr-xr-x.   2   0   0      6 Mar 23  2022 cron.daily
-rw-r--r--.   1   0   0      0 Nov 30  2023 cron.deny
drwxr-xr-x.   2   0   0     22 Mar 23  2022 cron.hourly
drwxr-xr-x.   2   0   0      6 Mar 23  2022 cron.monthly
drwxr-xr-x.   2   0   0      6 Mar 23  2022 cron.weekly
-rw-r--r--.   1   0   0    451 Mar 23  2022 crontab
drwxr-xr-x.   6   0   0     81 Nov 30 22:23 crypto-policies
-rw-------.   1   0   0      0 Nov 30 22:22 crypttab
-rw-r--r--.   1   0   0   1401 Feb  7  2024 csh.cshrc
-rw-r--r--.   1   0   0   1112 Feb  7  2024 csh.login
drwxr-xr-x.   4   0   7   4096 May 12 15:46 cups
drwxr-xr-x.   2   0   0     34 Nov 30 22:26 cupshelpers
drwxr-xr-x.   4   0   0     78 Nov 30 22:24 dbus-1
drwxr-xr-x.   4   0   0     31 Nov 30 22:24 dconf
drwxr-xr-x.   2   0   0     33 Nov 30 22:32 default
drwxr-xr-x.   2   0   0     40 Nov 30 22:25 depmod.d
drwxr-xr-x.   3   0   0     24 Nov 30 22:27 dhcp
drwxr-xr-x.   8   0   0    128 Nov 30 22:23 dnf
-rw-r--r--.   1   0 981  27839 Mar 15  2024 dnsmasq.conf
drwxr-xr-x.   2   0 981      6 Mar 15  2024 dnsmasq.d
-rw-r--r--.   1   0   0    117 Aug 19  2024 dracut.conf
drwxr-xr-x.   2   0   0      6 Aug 19  2024 dracut.conf.d
drwxr-xr-x.   3   0   0     37 Nov 30 22:24 egl
-rw-r--r--.   1   0   0   4760 Aug 10  2021 enscript.cfg
-rw-r--r--.   1   0   0      0 Feb  7  2024 environment
-rw-r--r--.   1   0   0   1362 Jun 23  2020 ethertypes
-rw-r--r--.   1   0   0      0 Jun 23  2020 exports
lrwxrwxrwx.   1   0   0     56 May 16  2023 favicon.png -> /usr/share/icons/hicolor/16x16/apps/fedora-logo-icon.png
-rw-r--r--.   1   0   0     66 Jun 23  2020 filesystems
drwxr-xr-x.   3   0   0     18 Nov 30 22:27 firefox
drwxr-x---.   8   0   0    149 Nov 30 22:27 firewalld
drwxr-xr-x.   3   0   0     23 Nov 30 22:26 flatpak
drwxr-xr-x.   3   0   0     38 Nov 30 22:24 fonts
drwxr-xr-x.   2   0   0     28 Nov 30 22:26 foomatic
-rw-r--r--.   1   0   0     20 Aug 20  2021 fprintd.conf
-rw-r--r--.   1   0   0    615 Nov 30 22:22 fstab
-rw-r--r--.   1   0   0     38 Jun 18  2024 fuse.conf
drwxr-xr-x.   4   0   0     64 Nov 30 22:26 fwupd
drwxr-xr-x.   2   0   0      6 Aug  1  2024 gcrypt
drwxr-xr-x.   6   0   0    107 Nov 30 22:26 gdm
drwxr-xr-x.   2   0   0     26 Nov 30 22:25 geoclue
drwxr-xr-x.   3   0   0     26 Nov 30 22:24 glvnd
drwxr-xr-x.   2   0   0      6 Apr 26  2023 gnupg
drwxr-xr-x.   4   0   0     40 Nov 30 22:23 groff
-rw-r--r--.   1   0   0    789 Mar 19 17:50 group
-rw-r--r--.   1   0   0    776 Nov 30 22:36 group-
drwx------.   2   0   0   4096 Nov 30 22:31 grub.d
lrwxrwxrwx.   1   0   0     22 Aug 15  2024 grub2.cfg -> ../boot/grub2/grub.cfg
----------.   1   0   0    632 Mar 19 17:50 gshadow
----------.   1   0   0    622 Nov 30 22:36 gshadow-
drwxr-xr-x.   3   0   0     20 Nov 30 22:24 gss
-rw-r--r--.   1   0   0      9 Jun 23  2020 host.conf
-rw-r--r--.   1   0   0      1 Nov 30 22:32 hostname
-rw-r--r--.   1   0   0    158 Jun 23  2020 hosts
drwxr-xr-x.   2   0   0     24 Nov 30 22:23 hp
-rw-r--r--.   1   0   0    490 Sep 10  2024 inittab
-rw-r--r--.   1   0   0    943 Jun 23  2020 inputrc
drwxr-xr-x.   2   0   0   4096 Apr  1 23:09 insights-client
drwxr-xr-x.   2   0   0    159 Nov 30 22:24 iproute2
drwxr-xr-x.   2   0   0     25 Nov 30 22:25 iscsi
-rw-r--r--.   1   0   0     23 Sep 24  2024 issue
drwxr-xr-x.   2   0   0     27 Nov 30 22:27 issue.d
-rw-r--r--.   1   0   0     22 Sep 24  2024 issue.net
drwxr-xr-x.   4   0   0     33 Nov 30 22:25 kdump
-rw-r--r--.   1   0   0   8979 Nov 30 22:25 kdump.conf
drwxr-xr-x.   3   0   0     38 Nov 30 22:32 kernel
drwxr-xr-x.   3   0   0     17 Nov 30 22:24 keys
drwxr-xr-x.   2   0   0      6 Oct 17  2022 keyutils
-rw-r--r--.   1   0   0    880 Jul  6  2024 krb5.conf
drwxr-xr-x.   2   0   0     83 Nov 30 22:27 krb5.conf.d
-rw-r--r--.   1   0   0  39003 Apr  1 23:42 ld.so.cache
-rw-r--r--.   1   0   0     28 Aug  2  2021 ld.so.conf
drwxr-xr-x.   2   0   0     39 Nov 30 22:27 ld.so.conf.d
-rw-r-----.   1   0   0    191 Jul 30  2024 libaudit.conf
drwxr-xr-x.   3   0   0     20 Nov 30 22:25 libblockdev
drwxr-xr-x.   2   0   0   4096 Nov 30 22:24 libibverbs.d
drwxr-xr-x.   2   0   0     35 Nov 30 22:23 libnl
drwxr-xr-x.   2   0   0      6 Aug 10  2021 libpaper.d
drwxr-xr-x.   6   0   0     70 Nov 30 22:23 libreport
drwxr-xr-x.   2   0   0     62 Nov 30 22:24 libssh
-rw-r--r--.   1   0   0   2391 Mar  1  2021 libuser.conf
-rw-r--r--.   1   0   0     19 Nov 30 22:32 locale.conf
lrwxrwxrwx.   1   0   0     36 Nov 30 22:32 localtime -> ../usr/share/zoneinfo/Asia/Hong_Kong
-rw-r--r--.   1   0   0   7779 Jul  3  2024 login.defs
-rw-r--r--.   1   0   0    496 Jun  7  2020 logrotate.conf
drwxr-xr-x.   2   0   0   4096 Apr  1 23:42 logrotate.d
drwxr-xr-x.   3   0   0     43 Nov 30 22:26 lsm
drwxr-xr-x.   7   0   0    115 Nov 30 22:25 lvm
-r--r--r--.   1   0   0     33 Nov 30 22:24 machine-id
-rw-r--r--.   1   0   0    111 Nov 30  2023 magic
-rw-r--r--.   1   0   0    272 Apr 22  2020 mailcap
-rw-r--r--.   1   0   0   5122 Sep 18  2024 makedumpfile.conf.sample
-rw-r--r--.   1   0   0   5235 Sep 21  2022 man_db.conf
drwxr-xr-x.   3   0   0     41 Nov 30 22:27 mcelog
drwxr-xr-x.   3   0   0     32 Nov 30 22:27 microcode_ctl
-rw-r--r--.   1   0   0  67454 Apr 22  2020 mime.types
-rw-r--r--.   1   0   0   1208 Dec 13  2023 mke2fs.conf
drwxr-xr-x.   2   0   0     54 Nov 30 22:27 modprobe.d
drwxr-xr-x.   2   0   0      6 Sep 10  2024 modules-load.d
-rw-r--r--.   1   0   0      0 Jun 23  2020 motd
drwxr-xr-x.   2   0   0     21 Mar 18 15:55 motd.d
lrwxrwxrwx.   1   0   0     19 Nov 30 22:24 mtab -> ../proc/self/mounts
drwxr-xr-x.   2   0   0     22 Nov 30 22:42 multipath
-rw-r--r--.   1   0   0  10373 Jul  4  2024 nanorc
-rw-r--r--.   1   0   0    767 Jul 30  2024 netconfig
-rw-r--r--.   1   0   0     58 Jun 23  2020 networks
drwx------.   3   0   0     66 Nov 30 22:24 nftables
drwxr-xr-x.   4   0   0   4096 Apr  1 23:42 nginx
lrwxrwxrwx.   1   0   0     29 Nov 30 22:32 nsswitch.conf -> /etc/authselect/nsswitch.conf
-rw-r--r--.   1   0   0   2108 Sep 28  2024 nsswitch.conf.bak
drwxr-xr-x.   2   0   0     57 Nov 30 22:27 nvme
drwxr-xr-x.   3   0   0     36 Nov 30 22:24 openldap
drwxr-xr-x.   3   0   0     20 Nov 30 22:27 opt
lrwxrwxrwx.   1   0   0     21 Sep 24  2024 os-release -> ../usr/lib/os-release
drwxr-xr-x.   3   0   0     23 Nov 30 22:24 ostree
drwxr-xr-x.   2   0   0   4096 Nov 30 22:32 pam.d
-rw-r--r--.   1   0   0     68 Aug 10  2021 papersize
-rw-r--r--.   1   0   0   2016 Mar 19 17:50 passwd
-rw-r--r--.   1   0   0   1954 Nov 30 22:36 passwd-
-rw-r--r--.   1   0   0   1362 Aug 11  2021 pbm2ppa.conf
-rw-r--r--.   1   0   0   2872 Aug 11  2021 pinforc
drwxr-xr-x.   3   0   0     21 Nov 30 22:23 pkcs11
drwxr-xr-x.   3   0   0     27 Nov 30 22:24 pkgconfig
drwxr-xr-x.  15   0   0   4096 Nov 30 22:36 pki
drwxr-xr-x.   2   0   0     28 Nov 30 22:25 plymouth
drwxr-xr-x.   5   0   0     52 Nov 30 22:23 pm
-rw-r--r--.   1   0   0   6300 Aug 11  2021 pnm2ppa.conf
drwxr-xr-x.   5   0   0     72 Nov 30 22:24 polkit-1
drwxr-xr-x.   2   0   0      6 Aug 11  2021 popt.d
-rw-r--r--.   1   0   0    233 Jun 23  2020 printcap
-rw-r--r--.   1   0   0   1899 Feb  7  2024 profile
drwxr-xr-x.   2   0   0   4096 Nov 30 22:28 profile.d
-rw-r--r--.   1   0   0   6568 Jun 23  2020 protocols
drwxr-xr-x.   2   0   0     25 Nov 30 22:24 pulse
drwxr-xr-x.   3   0   0     50 Nov 30 22:28 qemu-ga
drwxr-xr-x.   3   0   0     27 Nov 30 22:27 ras
drwxr-xr-x.   3   0   0     36 Nov 30 22:24 rc.d
lrwxrwxrwx.   1   0   0     13 Sep 10  2024 rc.local -> rc.d/rc.local
-rw-r--r--.   1   0   0     44 Sep 24  2024 redhat-release
-rw-r--r--.   1   0   0   1787 Oct 17  2022 request-key.conf
drwxr-xr-x.   2   0   0      6 Oct 17  2022 request-key.d
-rw-r--r--.   1   0   0    105 Feb 17 17:19 resolv.conf
drwxr-xr-x.   3   0   0     40 Nov 30 22:27 rhc
drwxr-xr-x.   6   0   0    105 Mar 19 17:46 rhsm
-rw-r--r--.   1   0   0   1634 Aug  2  2021 rpc
drwxr-xr-x.   2   0   0      6 Aug 15  2024 rpm
-rw-r--r--.   1   0   0    458 Apr 18  2024 rsyncd.conf
-rw-r--r--.   1   0   0   3380 Jan  8  2024 rsyslog.conf
drwxr-xr-x.   2   0   0      6 Jan  8  2024 rsyslog.d
drwxr-xr-x.   2   0   0     35 Nov 30 22:25 rwtab.d
drwxr-xr-x.   2   0   0     61 Nov 30 22:24 samba
drwxr-xr-x.   3   0   0   4096 Nov 30 22:25 sane.d
drwxr-xr-x.   2   0   0      6 Sep 13  2022 sasl2
drwxr-xr-x.   7   0   0   4096 Nov 30 22:24 security
drwxr-xr-x.   3   0   0     57 Nov 30 22:24 selinux
-rw-r--r--.   1   0   0 692252 Jun 23  2020 services
-rw-r--r--.   1   0   0    216 Feb 20  2024 sestatus.conf
drwxr-xr-x.   2   0   0     33 Nov 30 22:26 setroubleshoot
drwxr-xr-x.   3   0   0     21 Nov 30 22:23 sgml
----------.   1   0   0   1087 Mar 19 17:50 shadow
----------.   1   0   0   1066 Nov 30 22:36 shadow-
-rw-r--r--.   1   0   0     44 Jun 23  2020 shells
drwxr-xr-x.   3   0   0     78 Nov 30 22:23 skel
drwxr-xr-x.   3   0   0     74 Nov 30 22:28 smartmontools
drwxr-xr-x.   6   0   0     86 Nov 30 22:26 sos
drwxr-xr-x.   4   0   0     56 Nov 30 22:25 speech-dispatcher
drwxr-xr-x.   4   0   0   4096 Nov 30 22:34 ssh
drwxr-xr-x.   2   0   0     77 Nov 30 22:24 ssl
drwx------.   4 994 991     31 Nov 30 22:25 sssd
drwxr-xr-x.   2   0   0      6 Jun 25  2024 statetab.d
-rw-r--r--.   1   0   0     17 Nov 30 22:36 subgid
-rw-r--r--.   1   0   0      0 Jun 23  2020 subgid-
-rw-r--r--.   1   0   0     17 Nov 30 22:36 subuid
-rw-r--r--.   1   0   0      0 Jun 23  2020 subuid-
-rw-r-----.   1   0   0   3181 Jan 24  2024 sudo-ldap.conf
-rw-r-----.   1   0   0   3983 Jan 24  2024 sudo.conf
-r--r-----.   1   0   0   4328 Jan 24  2024 sudoers
drwxr-x---.   2   0   0      6 Jan 24  2024 sudoers.d
drwxr-xr-x.   3   0   0     24 Nov 30 22:23 swid
drwxr-xr-x.   3   0   0   4096 Nov 30 22:32 sysconfig
-rw-r--r--.   1   0   0    449 Sep 10  2024 sysctl.conf
drwxr-xr-x.   2   0   0     28 Nov 30 22:25 sysctl.d
lrwxrwxrwx.   1   0   0     14 Sep 24  2024 system-release -> redhat-release
-rw-r--r--.   1   0   0     41 Sep 24  2024 system-release-cpe
drwxr-xr-x.   4   0   0    166 Nov 30 22:25 systemd
drwxr-xr-x.   2   0   0      6 Aug 21  2023 terminfo
drwxr-xr-x.   2   0   0     22 Nov 30 22:26 tmpfiles.d
drwxr-xr-x.   3   0   0     51 Nov 30 22:24 tpm2-tss
-rw-r--r--.   1   0   0    375 Aug 28  2024 trusted-key.key
drwxr-xr-x.   3   0   0    136 Nov 30 22:27 tuned
drwxr-xr-x.   4   0   0     68 Nov 30 22:34 udev
drwxr-xr-x.   2   0   0     60 Nov 30 22:26 udisks2
-rw-r--r--.   1   0   0    624 Aug 10  2021 updatedb.conf
-rw-r--r--.   1   0   0   1523 Aug 11  2021 usb_modeswitch.conf
-rw-r--r--.   1   0   0     28 Nov 30 22:32 vconsole.conf
-rw-r--r--.   1   0   0   4017 Aug  5  2024 vimrc
-rw-r--r--.   1   0   0   1184 Aug  5  2024 virc
drwxr-xr-x.   4   0   0   4096 Nov 30 22:27 vmware-tools
drwxr-xr-x.   5   0   0     67 Nov 30 22:24 vulkan
-rw-r--r--.   1   0   0   4925 Jul 15  2024 wgetrc
drwxr-xr-x.   6   0   0     81 Nov 30 22:25 wireplumber
drwxr-xr-x.   2   0   0     33 Nov 30 22:25 wpa_supplicant
-rw-r--r--.   1   0   0    817 Aug 10  2021 xattr.conf
drwxr-xr-x.   6   0   0    125 Nov 30 22:25 xdg
drwxr-xr-x.   3   0   0     36 Nov 30 22:24 xml
drwxr-xr-x.   2   0   0     57 Nov 30 22:27 yum
lrwxrwxrwx.   1   0   0     12 Aug  6  2024 yum.conf -> dnf/dnf.conf
drwxr-xr-x.   2   0   0     44 Apr  8 19:09 yum.repos.d

/etc/crypto-policies:
total 20
drwxr-xr-x.   6 0 0   81 Nov 30 22:23 .
drwxr-xr-x. 136 0 0 8192 Apr  1 23:42 ..
drwxr-xr-x.   2 0 0 4096 Nov 30 22:31 back-ends
-rw-r--r--.   1 0 0    8 Nov 30 22:23 config
drwxr-xr-x.   2 0 0   32 Nov 30 22:26 local.d
drwxr-xr-x.   3 0 0   21 Nov 30 22:23 policies
drwxr-xr-x.   2 0 0   40 Nov 30 22:31 state

/etc/crypto-policies/back-ends:
total 8
drwxr-xr-x. 2 0 0 4096 Nov 30 22:31 .
drwxr-xr-x. 6 0 0   81 Nov 30 22:23 ..
lrwxrwxrwx. 1 0 0   43 Nov 30 22:31 bind.config -> /usr/share/crypto-policies/DEFAULT/bind.txt
lrwxrwxrwx. 1 0 0   45 Nov 30 22:31 gnutls.config -> /usr/share/crypto-policies/DEFAULT/gnutls.txt
lrwxrwxrwx. 1 0 0   43 Nov 30 22:31 java.config -> /usr/share/crypto-policies/DEFAULT/java.txt
lrwxrwxrwx. 1 0 0   49 Nov 30 22:31 javasystem.config -> /usr/share/crypto-policies/DEFAULT/javasystem.txt
lrwxrwxrwx. 1 0 0   43 Nov 30 22:31 krb5.config -> /usr/share/crypto-policies/DEFAULT/krb5.txt
lrwxrwxrwx. 1 0 0   48 Nov 30 22:31 libreswan.config -> /usr/share/crypto-policies/DEFAULT/libreswan.txt
lrwxrwxrwx. 1 0 0   45 Nov 30 22:31 libssh.config -> /usr/share/crypto-policies/DEFAULT/libssh.txt
-rw-r--r--. 1 0 0  447 Nov 30 22:31 nss.config
lrwxrwxrwx. 1 0 0   46 Nov 30 22:31 openssh.config -> /usr/share/crypto-policies/DEFAULT/openssh.txt
lrwxrwxrwx. 1 0 0   52 Nov 30 22:31 opensshserver.config -> /usr/share/crypto-policies/DEFAULT/opensshserver.txt
lrwxrwxrwx. 1 0 0   46 Nov 30 22:31 openssl.config -> /usr/share/crypto-policies/DEFAULT/openssl.txt
lrwxrwxrwx. 1 0 0   51 Nov 30 22:31 openssl_fips.config -> /usr/share/crypto-policies/DEFAULT/openssl_fips.txt
lrwxrwxrwx. 1 0 0   49 Nov 30 22:31 opensslcnf.config -> /usr/share/crypto-policies/DEFAULT/opensslcnf.txt

/etc/crypto-policies/state:
total 8
drwxr-xr-x. 2 0 0   40 Nov 30 22:31 .
drwxr-xr-x. 6 0 0   81 Nov 30 22:23 ..
-rw-r--r--. 1 0 0 2456 Nov 30 22:31 CURRENT.pol
-rw-r--r--. 1 0 0    8 Nov 30 22:31 current

/etc/dnf/vars:
total 0
drwxr-xr-x. 2 0 0   6 Aug  6  2024 .
drwxr-xr-x. 8 0 0 128 Nov 30 22:23 ..

/etc/pki/tls/private:
total 0
drwxr-xr-x. 2 0 0   6 Sep  5  2024 .
drwxr-xr-x. 6 0 0 143 Nov 30 22:24 ..

/etc/selinux/targeted/policy:
total 3572
drwxr-xr-x. 2 0 0      23 Nov 30 22:28 .
drwxr-xr-x. 5 0 0     133 Nov 30 22:28 ..
-rw-r--r--. 1 0 0 3655386 Nov 30 22:28 policy.33

/etc/ssh:
total 616
drwxr-xr-x.   4 0   0   4096 Nov 30 22:34 .
drwxr-xr-x. 136 0   0   8192 Apr  1 23:42 ..
-rw-r--r--.   1 0   0 578094 Jul  9  2024 moduli
-rw-r--r--.   1 0   0   1921 Jul  9  2024 ssh_config
drwxr-xr-x.   2 0   0     28 Nov 30 22:25 ssh_config.d
-rw-r-----.   1 0 101    492 Nov 30 22:34 ssh_host_ecdsa_key
-rw-r--r--.   1 0   0    162 Nov 30 22:34 ssh_host_ecdsa_key.pub
-rw-r-----.   1 0 101    387 Nov 30 22:34 ssh_host_ed25519_key
-rw-r--r--.   1 0   0     82 Nov 30 22:34 ssh_host_ed25519_key.pub
-rw-r-----.   1 0 101   2578 Nov 30 22:34 ssh_host_rsa_key
-rw-r--r--.   1 0   0    554 Nov 30 22:34 ssh_host_rsa_key.pub
-rw-------.   1 0   0   3667 Jul  9  2024 sshd_config
drwx------.   2 0   0     59 Nov 30 22:32 sshd_config.d

/etc/sysconfig:
total 96
drwxr-xr-x.   3 0 0 4096 Nov 30 22:32 .
drwxr-xr-x. 136 0 0 8192 Apr  1 23:42 ..
-rw-r--r--.   1 0 0  111 Nov 30 22:32 anaconda
-rw-r--r--.   1 0 0  403 Apr  4  2022 atd
-rw-r--r--.   1 0 0   50 Aug 12  2024 chronyd
-rw-r--r--.   1 0 0  150 Oct  1  2024 cpupower
-rw-r--r--.   1 0 0  110 Nov 30  2023 crond
-rw-r--r--.   1 0 0   73 Jul  3  2024 firewalld
-rw-r--r--.   1 0 0 1399 Mar 19  2024 irqbalance
-rw-r--r--.   1 0 0 2534 Sep 18  2024 kdump
-rw-r--r--.   1 0 0  185 Nov 30 22:32 kernel
-rw-r--r--.   1 0 0  310 Sep 21  2022 man-db
-rw-r--r--.   1 0 0   22 Nov 30 22:32 network
drwxr-xr-x.   2 0 0   33 Nov 30 22:25 network-scripts
-rw-------.   1 0 0  364 Jul  3  2024 nftables.conf
-rw-r--r--.   1 0 0 1912 Sep  2  2024 qemu-ga
-rw-r--r--.   1 0 0 2915 Aug 11  2024 raid-check
-rw-r--r--.   1 0 0 1160 Aug 16  2024 rasdaemon
-rw-r--r--.   1 0 0  196 Jan  8  2024 rsyslog
-rw-r--r--.   1 0 0    0 Mar 23  2022 run-parts
-rw-r--r--.   1 0 0  428 Aug  1  2024 samba
lrwxrwxrwx.   1 0 0   17 Nov 30 22:24 selinux -> ../selinux/config
-rw-r--r--.   1 0 0  201 Jan 23  2024 smartmontools
-rw-r-----.   1 0 0  384 Jul  9  2024 sshd
-rw-r--r--.   1 0 0  258 Feb 23  2024 wpa_supplicant

/run/systemd/journal:
total 4
drwxr-xr-x.  3 0 0  160 Feb 17 17:19 .
drwxr-xr-x. 21 0 0  520 May 12 15:53 ..
srw-rw-rw-.  1 0 0    0 Feb 17 17:19 dev-log
srw-------.  1 0 0    0 Feb 17 17:19 io.systemd.journal
-rw-r--r--.  1 0 0    8 Feb 17 17:19 kernel-seqnum
srw-rw-rw-.  1 0 0    0 Feb 17 17:19 socket
srw-rw-rw-.  1 0 0    0 Feb 17 17:19 stdout
drwxr-xr-x.  2 0 0 1700 May 12 15:54 streams

/usr/lib/udev/rules.d:
total 684
drwxr-xr-x. 2 0 0  8192 Nov 30 22:28 .
drwxr-xr-x. 4 0 0  4096 Nov 30 22:28 ..
-rw-r--r--. 1 0 0   321 Aug 11  2024 01-md-raid-creating.rules
-r--r--r--. 1 0 0  7492 Aug  8  2024 10-dm.rules
-r--r--r--. 1 0 0  2420 Aug  8  2024 11-dm-lvm.rules
-rw-r--r--. 1 0 0  4568 Aug  6  2024 11-dm-mpath.rules
-rw-r--r--. 1 0 0  1442 Aug  6  2024 11-dm-parts.rules
-r--r--r--. 1 0 0  2244 Aug  8  2024 13-dm-disk.rules
-rw-r--r--. 1 0 0   728 Sep 10  2024 40-elevator.rules
-rw-r--r--. 1 0 0  5976 Aug 10  2021 40-libgphoto2.rules
-rw-r--r--. 1 0 0  2014 Sep 10  2024 40-redhat.rules
-rw-r--r--. 1 0 0   458 Oct 31  2021 40-usb-blacklist.rules
-rw-r--r--. 1 0 0 42861 Aug 11  2021 40-usb_modeswitch.rules
-rw-r--r--. 1 0 0  5408 Sep 10  2024 50-udev-default.rules
-rw-r--r--. 1 0 0   704 Nov  1  2022 60-autosuspend.rules
-rw-r--r--. 1 0 0   703 Nov  1  2022 60-block.rules
-rw-r--r--. 1 0 0  1071 Nov  1  2022 60-cdrom_id.rules
-rw-r--r--. 1 0 0   413 Nov  1  2022 60-drm.rules
-rw-r--r--. 1 0 0   990 Nov  1  2022 60-evdev.rules
-rw-r--r--. 1 0 0   491 Nov  1  2022 60-fido-id.rules
-rw-r--r--. 1 0 0   282 Nov  1  2022 60-input-id.rules
-rw-r--r--. 1 0 0   129 Mar  6  2024 60-net.rules
-rw-r--r--. 1 0 0   616 Nov  1  2022 60-persistent-alsa.rules
-rw-r--r--. 1 0 0  2719 Nov  1  2022 60-persistent-input.rules
-rw-r--r--. 1 0 0  2204 Nov  1  2022 60-persistent-storage-tape.rules
-rw-r--r--. 1 0 0 10901 Sep 10  2024 60-persistent-storage.rules
-rw-r--r--. 1 0 0   769 Nov  1  2022 60-persistent-v4l.rules
-rw-r--r--. 1 0 0  1618 Nov  1  2022 60-sensor.rules
-rw-r--r--. 1 0 0  1136 Sep 10  2024 60-serial.rules
-rw-r--r--. 1 0 0   243 Apr 26  2024 60-tpm-udev.rules
-rw-r--r--. 1 0 0  3385 Aug 10  2021 60_flashrom.rules
-rw-r--r--. 1 0 0  6399 Jul 27  2024 61-gdm.rules
-rw-r--r--. 1 0 0   231 Aug 10  2021 61-gnome-bluetooth-rfkill.rules
-rw-r--r--. 1 0 0   292 Apr 14  2021 61-gnome-settings-daemon-rfkill.rules
-rw-r--r--. 1 0 0   458 Aug  5  2024 61-mutter.rules
-rw-r--r--. 1 0 0  6359 Nov  6  2021 61-scsi-sg3_id.rules
-rw-r--r--. 1 0 0  4541 Aug  6  2024 62-multipath.rules
-rw-r--r--. 1 0 0   624 Apr 29  2019 63-fc-wwpn-id.rules
-rw-r--r--. 1 0 0  2631 Aug 11  2024 63-md-raid-arrays.rules
-rw-r--r--. 1 0 0  2864 Oct 31  2021 63-scsi-sg3_symlink.rules
-rw-r--r--. 1 0 0   616 Sep 10  2024 64-btrfs.rules
-rw-r--r--. 1 0 0  2368 Aug 11  2024 64-md-raid-assembly.rules
-rw-r--r--. 1 0 0  1157 Dec  2  2021 65-libwacom.rules
-rw-r--r--. 1 0 0   118 Aug 24  2024 65-persistent-net-nbft.rules
-rw-r--r--. 1 0 0  4053 Jul 25  2022 65-sane-backends.rules
-rw-r--r--. 1 0 0   732 Sep 19  2017 65-scsi-cciss_id.rules
-rw-r--r--. 1 0 0  1392 Aug  6  2024 66-kpartx.rules
-rw-r--r--. 1 0 0   895 Aug 11  2024 66-md-auto-readd.rules
-rw-r--r--. 1 0 0  1142 Aug  6  2024 68-del-part-nodes.rules
-rw-r--r--. 1 0 0  4934 Aug 10  2021 69-cd-sensors.rules
-r--r--r--. 1 0 0  3657 Aug  8  2024 69-dm-lvm.rules
-rw-r--r--. 1 0 0  1945 Jan 22  2022 69-libmtp.rules
-rw-r--r--. 1 0 0   858 Aug 11  2024 69-md-clustered-confirm-device.rules
-rw-r--r--. 1 0 0   281 Nov  1  2022 70-camera.rules
-rw-r--r--. 1 0 0   104 Apr 25  2024 70-hypervfcopy.rules
-rw-r--r--. 1 0 0   100 Apr 25  2024 70-hypervkvp.rules
-rw-r--r--. 1 0 0   100 Apr 25  2024 70-hypervvss.rules
-rw-r--r--. 1 0 0   432 Nov  1  2022 70-joystick.rules
-rw-r--r--. 1 0 0   633 Jan 31  2024 70-libfprint-2.rules
-rw-r--r--. 1 0 0   184 Nov  1  2022 70-memory.rules
-rw-r--r--. 1 0 0   734 Nov  1  2022 70-mouse.rules
-rw-r--r--. 1 0 0  2046 Aug 24  2024 70-nvmf-autoconnect.rules
-rw-r--r--. 1 0 0   576 Nov  1  2022 70-power-switch.rules
-rw-r--r--. 1 0 0   845 Dec 15  2020 70-printers.rules
-rw-r--r--. 1 0 0   140 Jan 16  2023 70-spice-vdagentd.rules
-rw-r--r--. 1 0 0   473 Nov  1  2022 70-touchpad.rules
-rw-r--r--. 1 0 0  3460 Sep 10  2024 70-uaccess.rules
-rw-r--r--. 1 0 0  1138 Feb 10  2022 70-wacom.rules
-rw-r--r--. 1 0 0   522 Aug 24  2024 71-nvmf-netapp.rules
-rw-r--r--. 1 0 0   403 Aug 11  2021 71-prefixdevname.rules
-rw-r--r--. 1 0 0  3818 Sep 10  2024 71-seat.rules
-rw-r--r--. 1 0 0   643 Sep 10  2024 73-seat-late.rules
-rw-r--r--. 1 0 0   512 Sep 10  2024 75-net-description.rules
-rw-r--r--. 1 0 0   174 Nov  1  2022 75-probe_mtd.rules
-rw-r--r--. 1 0 0   936 Nov 11  2022 77-mm-broadmobi-port-types.rules
-rw-r--r--. 1 0 0  4401 Nov 11  2022 77-mm-cinterion-port-types.rules
-rw-r--r--. 1 0 0  1767 Nov 11  2022 77-mm-dell-port-types.rules
-rw-r--r--. 1 0 0   866 Nov 11  2022 77-mm-dlink-port-types.rules
-rw-r--r--. 1 0 0  8084 Nov 11  2022 77-mm-ericsson-mbm.rules
-rw-r--r--. 1 0 0  6416 Nov 11  2022 77-mm-fibocom-port-types.rules
-rw-r--r--. 1 0 0  1603 Nov 11  2022 77-mm-foxconn-port-types.rules
-rw-r--r--. 1 0 0   907 Nov 11  2022 77-mm-gosuncn-port-types.rules
-rw-r--r--. 1 0 0   525 Nov 11  2022 77-mm-haier-port-types.rules
-rw-r--r--. 1 0 0  2596 Nov 11  2022 77-mm-huawei-net-port-types.rules
-rw-r--r--. 1 0 0   697 Nov 11  2022 77-mm-linktop-port-types.rules
-rw-r--r--. 1 0 0 14434 Nov 11  2022 77-mm-longcheer-port-types.rules
-rw-r--r--. 1 0 0  3282 Nov 11  2022 77-mm-mtk-port-types.rules
-rw-r--r--. 1 0 0  2176 Nov 11  2022 77-mm-nokia-port-types.rules
-rw-r--r--. 1 0 0  1619 Nov 11  2022 77-mm-qcom-soc.rules
-rw-r--r--. 1 0 0  5063 Nov 11  2022 77-mm-quectel-port-types.rules
-rw-r--r--. 1 0 0  1856 Nov 11  2022 77-mm-sierra.rules
-rw-r--r--. 1 0 0  3876 Nov 11  2022 77-mm-simtech-port-types.rules
-rw-r--r--. 1 0 0 10677 Nov 11  2022 77-mm-telit-port-types.rules
-rw-r--r--. 1 0 0   739 Nov 11  2022 77-mm-tplink-port-types.rules
-rw-r--r--. 1 0 0  4215 Nov 11  2022 77-mm-ublox-port-types.rules
-rw-r--r--. 1 0 0  4602 Nov 11  2022 77-mm-x22x-port-types.rules
-rw-r--r--. 1 0 0 17179 Nov 11  2022 77-mm-zte-port-types.rules
-rw-r--r--. 1 0 0  4816 Nov  1  2022 78-sound-card.rules
-rw-r--r--. 1 0 0   600 Nov  1  2022 80-drivers.rules
-rw-r--r--. 1 0 0  1557 Aug 16  2021 80-iio-sensor-proxy.rules
-rw-r--r--. 1 0 0   207 Jul  6  2023 80-libinput-device-groups.rules
-rw-r--r--. 1 0 0  2142 Nov 11  2022 80-mm-candidate.rules
-rw-r--r--. 1 0 0   295 Nov  1  2022 80-net-setup-link.rules
-rw-r--r--. 1 0 0 10635 May 17  2024 80-udisks2.rules
-rw-r--r--. 1 0 0   528 Nov  1  2022 81-net-dhcp.rules
-rw-r--r--. 1 0 0   533 Aug 26  2024 84-nm-drivers.rules
-rw-r--r--. 1 0 0  2013 Aug 26  2024 85-nm-unmanaged.rules
-rw-r--r--. 1 0 0   166 Apr 26  2024 85-regulatory.rules
-rw-r--r--. 1 0 0   479 Jul  4  2024 90-alsa-restore.rules
-rw-r--r--. 1 0 0   359 Feb 19  2024 90-bolt.rules
-rw-r--r--. 1 0 0   281 Feb  8  2024 90-fwupd-devices.rules
-rw-r--r--. 1 0 0    70 May  8  2020 90-iprutils.rules
-rw-r--r--. 1 0 0  1098 Jul  6  2023 90-libinput-fuzz-override.rules
-rw-r--r--. 1 0 0   588 Aug 26  2024 90-nm-thunderbolt.rules
-rw-r--r--. 1 0 0 13228 Jan 10  2024 90-pipewire-alsa.rules
-rw-r--r--. 1 0 0   489 Sep 10  2024 90-vconsole.rules
-rw-r--r--. 1 0 0    56 Jun  5  2024 91-drm-modeset.rules
-rw-r--r--. 1 0 0   847 Nov  2  2020 95-cd-devices.rules
-r--r--r--. 1 0 0   483 Aug  8  2024 95-dm-notify.rules
-rw-r--r--. 1 0 0  8109 Aug 23  2021 95-upower-hid.rules
-rw-r--r--. 1 0 0   354 Aug 23  2021 95-upower-wup.rules
-rw-r--r--. 1 0 0   695 Sep 18  2024 98-kexec.rules
-rw-r--r--. 1 0 0   130 Sep  2  2024 99-qemu-guest-agent.rules
-rw-r--r--. 1 0 0  5039 Sep 10  2024 99-systemd.rules
-rw-r--r--. 1 0 0   459 Feb  6  2024 99-vmware-scsi-udev.rules
-rw-r--r--. 1 0 0   435 Nov  1  2022 README

/var/lib/rpm:
total 104960
drwxr-xr-x.  2 0 0        91 Aug 15  2024 .
drwxr-xr-x. 56 0 0      4096 Apr  1 23:42 ..
-rw-r--r--.  1 0 0         0 Nov 30 22:23 .rpm.lock
-rw-r--r--.  1 0 0 107442176 Apr  1 23:42 rpmdb.sqlite
-rw-r--r--.  1 0 0     32768 May 12 15:54 rpmdb.sqlite-shm
-rw-r--r--.  1 0 0         0 Apr  1 23:42 rpmdb.sqlite-wal

/var/lib/sss/pubconf/krb5.include.d:
total 0
drwxr-xr-x. 2 994 991  6 Jul 22  2024 .
drwxr-xr-x. 3 994 991 28 Nov 30 22:25 ..

/var/log/audit:
total 1544
drwx------.  2 0 0      23 Nov 30 22:34 .
drwxr-xr-x. 16 0 0    4096 May 11 00:00 ..
-rw-------.  1 0 0 1569611 May 12 15:54 audit.log

/var/spool/cron:
total 0
drwx------.  2 0 0   6 Nov 30  2023 .
drwxr-xr-x. 10 0 0 106 Nov 30 22:27 ..