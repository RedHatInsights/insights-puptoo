/bin/ls: cannot access '/etc/nova/migration': No such file or directory
/bin/ls: cannot access '/etc/pki/ovirt-vmconsole': No such file or directory
/bin/ls: cannot access '/etc/watchdog.d/': No such file or directory
/etc:
total 1088
drwxr-xr-x. 96   0   0   8192 Jul 26 14:40 .
dr-xr-xr-x. 17   0   0    224 Jul 26 14:31 ..
-rw-------.  1   0   0      0 Jan 13  2020 .pwd.lock
-rw-r--r--.  1   0   0    208 Jul 26 14:32 .updated
-rw-r--r--.  1   0   0   4536 Jul 14  2021 DIR_COLORS
-rw-r--r--.  1   0   0   5214 Jul 14  2021 DIR_COLORS.256color
-rw-r--r--.  1   0   0   4618 Jul 14  2021 DIR_COLORS.lightbgcolor
-rw-r--r--.  1   0   0     94 May 11  2019 GREP_COLORS
drwxr-xr-x.  7   0   0    168 Jul 26 14:31 NetworkManager
drwxr-xr-x.  2   0   0     48 Jul 26 14:32 PackageKit
drwxr-xr-x.  6   0   0     70 Jun 22  2021 X11
-rw-r--r--.  1   0   0     16 Jan 13  2020 adjtime
-rw-r--r--.  1   0   0   1529 May 15  2020 aliases
drwxr-xr-x.  2   0   0    129 Jul 28  2021 alternatives
-rw-r--r--.  1   0   0    541 Nov  8  2019 anacrontab
drwxr-x---.  4   0   0    100 Apr 24  2020 audit
drwxr-xr-x.  3   0   0    228 Jul 26 14:33 authselect
drwxr-xr-x.  2   0   0     56 Jul 26 14:33 bash_completion.d
-rw-r--r--.  1   0   0   3019 May 15  2020 bashrc
-rw-r--r--.  1   0   0    535 Apr 21  2021 bindresvport.blacklist
drwxr-xr-x.  2   0   0      6 Dec 21  2021 binfmt.d
-rw-r--r--.  1   0   0     30 Nov 10  2021 centos-release
-rw-r--r--.  1   0   0     42 Nov 10  2021 centos-release-upstream
drwxr-xr-x.  2   0   0      6 Jul 28  2021 chkconfig.d
-rw-r--r--.  1   0   0   1085 Jun 24  2021 chrony.conf
-rw-r-----.  1   0 990    540 May 12  2021 chrony.keys
drwxr-xr-x.  2   0   0     26 Dec 21  2021 cifs-utils
drwxr-xr-x.  4   0   0     83 Jul 26 14:33 cloud
drwxr-xr-x.  4   0   0     42 Sep 10  2021 cockpit
drwxr-xr-x.  2   0   0     21 Jan 13  2020 cron.d
drwxr-xr-x.  2   0   0     23 May 16  2020 cron.daily
-rw-r--r--.  1   0   0      0 Nov  8  2019 cron.deny
drwxr-xr-x.  2   0   0     22 Jan 12  2021 cron.hourly
drwxr-xr-x.  2   0   0      6 Jan 12  2021 cron.monthly
drwxr-xr-x.  2   0   0      6 Jan 12  2021 cron.weekly
-rw-r--r--.  1   0   0    451 Jan 12  2021 crontab
drwxr-xr-x.  6   0   0     81 Jul 26 14:31 crypto-policies
-rw-------.  1   0   0      0 Jan 13  2020 crypttab
-rw-r--r--.  1   0   0   1629 May 15  2020 csh.cshrc
-rw-r--r--.  1   0   0   1078 May 15  2020 csh.login
drwxr-xr-x.  4   0   0     78 May  8  2021 dbus-1
drwxr-xr-x.  3   0   0     16 Jan 13  2020 dconf
drwxr-xr-x.  2   0   0     33 Jul 26 14:33 default
drwxr-xr-x.  2   0   0     23 Jul 26 14:31 depmod.d
drwxr-x---.  3   0   0     45 Jul 22  2021 dhcp
drwxr-xr-x.  8   0   0    128 Jul 26 14:31 dnf
-rw-r--r--.  1   0   0    117 Sep 29  2021 dracut.conf
drwxr-xr-x.  2   0   0     36 Jul 26 14:32 dracut.conf.d
-rw-r--r--.  1   0   0      0 May 15  2020 environment
-rw-r--r--.  1   0   0   1362 Sep 10  2018 ethertypes
-rw-r--r--.  1   0   0      0 Sep 10  2018 exports
drwxr-xr-x.  2   0   0      6 Jul 30  2021 exports.d
lrwxrwxrwx.  1   0   0     56 Nov 12  2021 favicon.png -> /usr/share/icons/hicolor/16x16/apps/fedora-logo-icon.png
-rw-r--r--.  1   0   0     66 Sep 10  2018 filesystems
drwxr-x---.  3   0   0     19 Jan 13  2020 firewalld
drwxr-xr-x.  3   0   0     38 Jan 13  2020 fonts
-rw-r--r--.  1   0   0    427 Jan 13  2020 fstab
drwxr-xr-x.  2   0   0     25 Jun 29  2021 gcrypt
drwxr-xr-x.  2   0   0      6 May 15  2020 gnupg
drwxr-xr-x.  4   0   0     40 Jan 13  2020 groff
-rw-r--r--.  1   0   0    636 Jul 26 14:33 group
-rw-r--r--.  1   0   0    624 Jul 26 14:33 group-
lrwxrwxrwx.  1   0   0     20 Jan 13  2020 grub.conf -> /boot/grub/grub.conf
drwx------.  2   0   0    288 Jul 26 14:33 grub.d
lrwxrwxrwx.  1   0   0     22 Nov  8  2021 grub2.cfg -> ../boot/grub2/grub.cfg
----------.  1   0   0    508 Jul 26 14:33 gshadow
----------.  1   0   0    499 Jul 26 14:33 gshadow-
drwxr-xr-x.  3   0   0     20 Aug 26  2021 gss
drwxr-xr-x.  2   0   0     79 Dec  3  2020 gssproxy
-rw-r--r--.  1   0   0      9 Sep 10  2018 host.conf
-rw-r--r--.  1   0   0     48 Jul 26 14:25 hostname
-rw-r--r--.  1   0   0    159 Jan 13  2020 hosts
-rw-r--r--.  1   0   0   4849 Jul 30  2021 idmapd.conf
lrwxrwxrwx.  1   0   0     11 Jul 28  2021 init.d -> rc.d/init.d
-rw-r--r--.  1   0   0    490 Dec 21  2021 inittab
-rw-r--r--.  1   0   0    942 Sep 10  2018 inputrc
drwxr-xr-x.  2   0   0   4096 Jul 26 14:41 insights-client
drwxr-xr-x.  2   0   0    159 Jul 26 14:31 iproute2
-rw-r--r--.  1   0   0     23 Nov 10  2021 issue
drwxr-xr-x.  2   0   0     27 Jan 13  2020 issue.d
-rw-r--r--.  1   0   0     22 Nov 10  2021 issue.net
drwxr-xr-x.  4   0   0     33 Jul 26 14:32 kdump
-rw-r--r--.  1   0   0   8550 Jul 26 14:32 kdump.conf
drwxr-xr-x.  4   0   0     41 Dec 21  2021 kernel
drwxr-xr-x.  2   0   0      6 Jun 19  2021 keyutils
-rw-r--r--.  1   0   0    812 Aug 26  2021 krb5.conf
drwxr-xr-x.  2   0   0     55 Jul 26 14:33 krb5.conf.d
-rw-r--r--.  1   0   0  14631 Jul 26 14:40 ld.so.cache
-rw-r--r--.  1   0   0     28 Aug 24  2021 ld.so.conf
drwxr-xr-x.  2   0   0    131 Jul 26 14:32 ld.so.conf.d
-rw-r-----.  1   0   0    191 Nov  4  2019 libaudit.conf
drwxr-xr-x.  2   0   0    246 Jul 26 14:32 libibverbs.d
drwxr-xr-x.  2   0   0     35 Apr  7  2020 libnl
drwxr-xr-x.  6   0   0     70 Aug 24  2020 libreport
drwxr-xr-x.  2   0   0     62 Jul 26 14:31 libssh
-rw-r--r--.  1   0   0   2391 Jul 23  2015 libuser.conf
-rw-r--r--.  1   0   0     17 Jul 26 14:25 locale.conf
lrwxrwxrwx.  1   0   0     25 Jan 13  2020 localtime -> ../usr/share/zoneinfo/UTC
-rw-r--r--.  1   0   0   2512 Aug 18  2021 login.defs
-rw-r--r--.  1   0   0    438 Feb 19  2018 logrotate.conf
drwxr-xr-x.  2   0   0    140 Jul 26 14:38 logrotate.d
-r--r--r--.  1   0   0     33 Jul 26 14:24 machine-id
-rw-r--r--.  1   0   0    111 May  8  2021 magic
-rw-r--r--.  1   0   0   5122 Dec 21  2021 makedumpfile.conf.sample
-rw-r--r--.  1   0   0   5165 Jun 29  2021 man_db.conf
drwxr-xr-x.  3   0   0     32 Jul 24  2021 microcode_ctl
-rw-r--r--.  1   0   0   1108 Jun 24  2021 mke2fs.conf
drwxr-xr-x.  2   0   0     81 Jul 26 14:33 modprobe.d
drwxr-xr-x.  2   0   0      6 Dec 21  2021 modules-load.d
-rw-r--r--.  1   0   0      0 Sep 10  2018 motd
drwxr-xr-x.  2   0   0     44 Jul 26 14:40 motd.d
lrwxrwxrwx.  1   0   0     19 Jan 13  2020 mtab -> ../proc/self/mounts
-rw-r--r--.  1   0   0    767 Apr 21  2021 netconfig
-rw-r--r--.  1   0   0     58 Sep 10  2018 networks
-rw-r--r--.  1   0   0   1160 Jul 30  2021 nfs.conf
-rw-r--r--.  1   0   0   3606 Jul 30  2021 nfsmount.conf
lrwxrwxrwx.  1   0   0     29 Jul 26 14:33 nsswitch.conf -> /etc/authselect/nsswitch.conf
-rw-r--r--.  1   0   0   1498 Nov  6  2019 nsswitch.conf.bak
-rw-r--r--.  1   0   0   2197 Aug 24  2021 nsswitch.conf.rpmnew
drwxr-xr-x.  2   0   0      6 Dec 17  2020 oddjob
-rw-r--r--.  1   0   0   4922 Dec 17  2020 oddjobd.conf
drwxr-xr-x.  2   0   0     70 Dec 17  2020 oddjobd.conf.d
drwxr-xr-x.  3   0   0     36 Aug 10  2021 openldap
drwxr-xr-x.  2   0   0      6 Jun 22  2021 opt
lrwxrwxrwx.  1   0   0     21 Nov 10  2021 os-release -> ../usr/lib/os-release
drwxr-xr-x.  2   0   0   4096 Jul 26 14:38 pam.d
-rw-r--r--.  1   0   0   1543 Jul 26 14:33 passwd
-rw-r--r--.  1   0   0   1469 Jul 26 14:33 passwd-
drwxr-xr-x.  3   0   0     21 Jan 12  2021 pkcs11
drwxr-xr-x. 11   0   0    148 Jul 26 14:38 pki
drwxr-xr-x.  5   0   0     52 Jun 22  2021 pm
drwxr-xr-x.  5   0   0     72 Jun  2  2021 polkit-1
drwxr-xr-x.  2   0   0      6 Jan 19  2021 popt.d
drwxr-xr-x.  2   0   0     24 Jul 26 14:31 prelink.conf.d
-rw-r--r--.  1   0   0    233 Sep 10  2018 printcap
-rw-r--r--.  1   0   0   2123 May 15  2020 profile
drwxr-xr-x.  2   0   0   4096 Jul 26 14:31 profile.d
-rw-r--r--.  1   0   0   6568 Sep 10  2018 protocols
drwxr-xr-x.  3   0   0     50 Jul 26 14:33 qemu-ga
drwxr-xr-x.  2   0   0     27 Jul 26 14:33 qemu-kvm
drwxr-xr-x. 10   0   0    127 Feb 19  2021 rc.d
lrwxrwxrwx.  1   0   0     13 Dec 21  2021 rc.local -> rc.d/rc.local
lrwxrwxrwx.  1   0   0     10 Jul 28  2021 rc0.d -> rc.d/rc0.d
lrwxrwxrwx.  1   0   0     10 Jul 28  2021 rc1.d -> rc.d/rc1.d
lrwxrwxrwx.  1   0   0     10 Jul 28  2021 rc2.d -> rc.d/rc2.d
lrwxrwxrwx.  1   0   0     10 Jul 28  2021 rc3.d -> rc.d/rc3.d
lrwxrwxrwx.  1   0   0     10 Jul 28  2021 rc4.d -> rc.d/rc4.d
lrwxrwxrwx.  1   0   0     10 Jul 28  2021 rc5.d -> rc.d/rc5.d
lrwxrwxrwx.  1   0   0     10 Jul 28  2021 rc6.d -> rc.d/rc6.d
drwxr-xr-x.  3   0   0     38 Jul 26 14:32 rdma
lrwxrwxrwx.  1   0   0     14 Nov 10  2021 redhat-release -> centos-release
-rw-r--r--.  1   0   0   1787 Jun 19  2021 request-key.conf
drwxr-xr-x.  2   0   0     30 Jun 19  2021 request-key.d
-rw-r--r--.  1   0   0     76 Jul 26 14:25 resolv.conf
drwxr-xr-x.  6   0   0    104 Jul 26 14:38 rhsm
-rw-r--r--.  1   0   0   1634 Aug  1  2018 rpc
drwxr-xr-x.  2   0   0     25 Oct 15  2021 rpm
-rw-r--r--.  1   0   0   3186 Aug 10  2021 rsyslog.conf
drwxr-xr-x.  2   0   0     31 Dec 21  2021 rsyslog.d
drwxr-xr-x.  2   0   0     35 Dec 21  2021 rwtab.d
drwxr-xr-x.  2   0   0      6 May 15  2020 sasl2
drwxr-xr-x.  7   0   0   4096 Jul 26 14:31 security
drwxr-xr-x.  3   0   0     57 Jul 26 14:31 selinux
-rw-r--r--.  1   0   0 692252 May 15  2020 services
-rw-r--r--.  1   0   0    216 Sep 30  2021 sestatus.conf
drwxr-xr-x.  2   0   0     33 Sep 30  2021 setroubleshoot
----------.  1   0   0    745 Jul 26 14:33 shadow
----------.  1   0   0    725 Jul 26 14:33 shadow-
-rw-r--r--.  1   0   0     44 Sep 10  2018 shells
drwxr-xr-x.  2   0   0     62 Jul 26 14:31 skel
drwxr-xr-x.  6   0   0     86 Jul 26 14:32 sos
drwxr-xr-x.  3   0   0    271 Jul 26 14:33 ssh
drwxr-xr-x.  2   0   0     19 Jul 26 14:31 ssl
drwx------.  4 996 993     31 Dec 21  2021 sssd
-rw-r--r--.  1   0   0     20 Jul 26 14:25 subgid
-rw-r--r--.  1   0   0      0 Sep 10  2018 subgid-
-rw-r--r--.  1   0   0     20 Jul 26 14:25 subuid
-rw-r--r--.  1   0   0      0 Sep 10  2018 subuid-
-rw-r-----.  1   0   0   3181 Oct 25  2021 sudo-ldap.conf
-rw-r-----.  1   0   0   1786 Oct 25  2021 sudo.conf
-r--r-----.  1   0   0   4359 Jan 13  2020 sudoers
drwxr-x---.  2   0   0     33 Oct 25  2021 sudoers.d
drwxr-xr-x.  6   0   0   4096 Jul 26 14:33 sysconfig
-rw-r--r--.  1   0   0    449 Dec 21  2021 sysctl.conf
drwxr-xr-x.  2   0   0     28 Dec 21  2021 sysctl.d
lrwxrwxrwx.  1   0   0     14 Nov 10  2021 system-release -> centos-release
-rw-r--r--.  1   0   0     23 Nov 10  2021 system-release-cpe
drwxr-xr-x.  4   0   0    150 Jul 26 14:31 systemd
-rw-r-----.  1   0  59   7046 Nov 16  2020 tcsd.conf
drwxr-xr-x.  2   0   0      6 Jun  1  2021 terminfo
drwxr-xr-x.  2   0   0      6 Dec 21  2021 tmpfiles.d
drwxr-xr-x.  3   0   0    136 Jul 26 14:33 tuned
drwxr-xr-x.  4   0   0     68 Jul 26 14:36 udev
drwxr-xr-x.  2   0   0     45 Jul 26 14:32 unbound
-rw-r--r--.  1   0   0     28 Jan 13  2020 vconsole.conf
-rw-r--r--.  1   0   0   1204 Sep 22  2021 virc
-rw-r--r--.  1   0   0    642 Dec  9  2016 xattr.conf
drwxr-xr-x.  4   0   0     38 Jun 22  2021 xdg
drwxr-xr-x.  2   0   0      6 Jun 22  2021 xinetd.d
drwxr-xr-x.  2   0   0     57 Jul 26 14:33 yum
lrwxrwxrwx.  1   0   0     12 Sep 17  2021 yum.conf -> dnf/dnf.conf
drwxr-xr-x.  2   0   0   4096 Jul 26 14:39 yum.repos.d

/etc/cloud/cloud.cfg.d:
total 8
drwxr-xr-x. 2 0 0   42 Jul 26 14:33 .
drwxr-xr-x. 4 0 0   83 Jul 26 14:33 ..
-rw-r--r--. 1 0 0 2070 Feb 23  2021 05_logging.cfg
-rw-r--r--. 1 0 0  167 Feb 23  2021 README

/etc/pki/tls/certs:
total 0
drwxr-xr-x. 2 0 0  54 Jul 26 14:31 .
drwxr-xr-x. 5 0 0 104 Jul 26 14:31 ..
lrwxrwxrwx. 1 0 0  49 Sep 22  2021 ca-bundle.crt -> /etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem
lrwxrwxrwx. 1 0 0  55 Sep 22  2021 ca-bundle.trust.crt -> /etc/pki/ca-trust/extracted/openssl/ca-bundle.trust.crt

/etc/pki/tls/private:
total 0
drwxr-xr-x. 2 0 0   6 Dec  2  2021 .
drwxr-xr-x. 5 0 0 104 Jul 26 14:31 ..

/etc/rc.d/init.d:
total 24
drwxr-xr-x.  2 0 0    37 Jul 26 14:31 .
drwxr-xr-x. 10 0 0   127 Feb 19  2021 ..
-rw-r--r--.  1 0 0  1161 Dec 21  2021 README
-rw-r--r--.  1 0 0 18434 Feb 15  2021 functions

/etc/selinux/targeted/policy:
total 8384
drwxr-xr-x. 2 0 0      23 Jul 26 14:32 .
drwxr-xr-x. 5 0 0     133 Jul 26 14:32 ..
-rw-r--r--. 1 0 0 8584595 Jul 26 14:32 policy.31

/etc/sysconfig:
total 76
drwxr-xr-x.  6 0 0 4096 Jul 26 14:33 .
drwxr-xr-x. 96 0 0 8192 Jul 26 14:40 ..
-rw-r--r--.  1 0 0  112 Jan 13  2020 anaconda
-rw-r--r--.  1 0 0   37 Jan 13  2020 authconfig
-rw-r--r--.  1 0 0   46 Jun 24  2021 chronyd
drwxr-xr-x.  2 0 0    6 Feb 19  2021 console
-rw-r--r--.  1 0 0  150 Dec 22  2021 cpupower
-rw-r--r--.  1 0 0  110 Nov  8  2019 crond
-rw-r--r--.  1 0 0   17 Jan 13  2020 firstboot
lrwxrwxrwx.  1 0 0   15 Nov  8  2021 grub -> ../default/grub
-rw-r--r--.  1 0 0  903 Feb  2  2021 irqbalance
-rw-r--r--.  1 0 0 2478 Dec 21  2021 kdump
-rw-r--r--.  1 0 0  180 Jul 26 14:32 kernel
-rw-r--r--.  1 0 0  310 Jun 29  2021 man-db
drwxr-xr-x.  2 0 0    6 Feb 19  2021 modules
-rw-r--r--.  1 0 0  139 Jul 26 14:25 network
drwxr-xr-x.  2 0 0   42 Nov  9  2021 network-scripts
-rw-r--r--.  1 0 0  911 Dec 21  2021 qemu-ga
drwxr-xr-x.  4 0 0   64 Jan 13  2020 rhn
-rw-r--r--.  1 0 0   73 Dec  2  2020 rpcbind
-rw-r--r--.  1 0 0  196 Aug 10  2021 rsyslog
-rw-r--r--.  1 0 0    0 Jan 12  2021 run-parts
lrwxrwxrwx.  1 0 0   17 Jan 13  2020 selinux -> ../selinux/config
-rw-r-----.  1 0 0  591 Jul 13  2021 sshd
