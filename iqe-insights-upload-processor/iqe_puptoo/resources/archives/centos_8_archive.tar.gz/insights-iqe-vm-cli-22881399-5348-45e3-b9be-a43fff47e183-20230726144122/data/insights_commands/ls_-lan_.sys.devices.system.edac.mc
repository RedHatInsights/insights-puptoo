total 0
drwxr-xr-x. 3 0 0    0 Jul 26 14:36 .
drwxr-xr-x. 4 0 0    0 Jul 26 14:36 ..
drwxr-xr-x. 2 0 0    0 Jul 26 14:36 power
lrwxrwxrwx. 1 0 0    0 Jul 26 14:36 subsystem -> ../../../../bus/edac
-rw-r--r--. 1 0 0 4096 Jul 26 14:36 uevent
